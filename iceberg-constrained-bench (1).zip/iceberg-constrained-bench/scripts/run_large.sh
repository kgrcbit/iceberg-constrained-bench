#!/bin/bash
cd "$(dirname "$0")/.."
# Large-scale extension: cold pass + 1 warm pass, 2 fresh-process repetitions per cell
python3 runner.py duckdb,polars-stream,polars-tuned 16,32 single 1 2
python3 runner.py polars 16,32 single 1 1
python3 runner.py spark-local 16,32 single 1 2
echo LARGEDONE
