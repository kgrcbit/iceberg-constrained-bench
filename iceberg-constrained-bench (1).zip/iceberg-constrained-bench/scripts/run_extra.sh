#!/bin/bash
cd "$(dirname "$0")/.."
python3 runner.py polars-stream 1,2,4,8 single 3 3
python3 runner.py polars-stream 1,4 conc 1,2,4 2
echo EXTRADONE
