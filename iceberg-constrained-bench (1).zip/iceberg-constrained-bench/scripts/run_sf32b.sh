#!/bin/bash
cd "$(dirname "$0")/.."
rm -rf /tmp/blockmgr-* /tmp/spark-*
( while true; do du -sm /tmp/blockmgr-* 2>/dev/null | awk '{s+=$1} END {print strftime("%T"), s+0}' >> results/sf32b_scratch.log; sleep 15; done ) &
MON=$!
python3 runner.py spark-local-tuned 32 single 1 1
kill $MON
echo SF32BDONE
