#!/bin/bash
cd "$(dirname "$0")/.."
# warm the lazily-restored disk blocks first (read every SF1-8 data file once)
cat warehouse/sf1/*/data/* warehouse/sf2/*/data/* warehouse/sf4/*/data/* warehouse/sf8/*/data/* > /dev/null
python3 runner.py duckdb-1t 1,2,4,8 single 3 2
# parity check vs. earlier session: DuckDB 2 threads, written to a separate folder
python3 - <<PY
import runner; runner.OUT = "$PWD/results/runs_recheck"
for sf in (1, 8): runner.run("duckdb", sf, "single", 3, 9)
PY
echo COSTDONE
