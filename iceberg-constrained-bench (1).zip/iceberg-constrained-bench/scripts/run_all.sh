#!/bin/bash
cd "$(dirname "$0")/.."
python3 runner.py duckdb,polars 1,2,4,8 single 3 3
python3 runner.py spark-local,spark-cluster 1,2,4,8 single 3 3
python3 runner.py duckdb,polars,spark-local,spark-cluster 1,4 conc 1,2,4 2
python3 runner.py polars-sql 1 single 0 1
echo ALLDONE
