#!/bin/bash
cd "$(dirname "$0")/.."
mkdir -p results/runs_old_nrss
for e in duckdb polars; do for f in results/runs/${e}_sf*_single3_r*.json results/runs/${e}_sf*_conc*_r*.json; do [ -f "$f" ] && python3 -c "import json,sys;r=json.load(open('$f'));sys.exit(0 if len(r['samples'][0])==4 else 1)" 2>/dev/null || mv "$f" results/runs_old_nrss/ 2>/dev/null; done; done
python3 runner.py duckdb,polars 1,2,4,8 single 3 3
python3 runner.py duckdb,polars 1,4 conc 1,2,4 2
echo EXTRA2DONE
