#!/bin/bash
cd "$(dirname "$0")/.."
python3 runner.py spark-local-default 1,2,4,8 single 3 3
echo REV2BDONE
