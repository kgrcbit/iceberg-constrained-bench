#!/bin/bash
cd "$(dirname "$0")/.."
pkill -f run_large.sh; pkill -f "runner.py spark-local"; sleep 2; pkill -f "worker.py spark-local 32"; sleep 3
rm -rf /tmp/blockmgr-* /tmp/spark-*
mkdir -p results/runs_failed_disk && mv results/runs/spark-local_sf32_single1_r*.json results/runs_failed_disk/ 2>/dev/null
# SF16 cells are complete: free its 4 GB for SF32 shuffle scratch
python3 - <<PY
import sys; sys.path.insert(0,'$PWD')
from engines import catalog
c=catalog()
for t in ["region","nation","supplier","customer","part","partsupp","orders","lineitem"]:
    c.purge_table(f"sf16.{t}") if hasattr(c,'purge_table') else c.drop_table(f"sf16.{t}")
PY
rm -rf warehouse/sf16
df -h . | tail -1
python3 runner.py spark-local 32 single 1 2
echo SF32DONE
