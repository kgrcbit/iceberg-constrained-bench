#!/bin/bash
cd "$(dirname "$0")/.."
python3 runner.py polars-tuned 1,2,4,8 single 3 1
for r in 3 4 5 6; do python3 - <<PY
import runner; runner.run("polars-tuned", 4, "conc", 4, $r); runner.run("polars", 4, "conc", 4, $r); runner.run("polars-stream", 4, "conc", 4, $r); runner.run("duckdb", 4, "conc", 4, $r)
PY
done
echo FIX2DONE
