#!/bin/bash
cd "$(dirname "$0")/.."
python3 runner.py spark-local-default 1,8 single 3 2
python3 runner.py spark-local-tuned 1,8 single 3 2
echo REV2DONE
