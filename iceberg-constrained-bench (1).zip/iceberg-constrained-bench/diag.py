"""Diagnostics: run one query variant in a child process and record peak RSS + latency.

usage: python3 diag.py <variant> <sf>       (child)
       python3 diag.py run <sf> v1,v2,...   (parent: drop cache, run each variant 3x, sample RSS)
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import sys, os, time, json, subprocess, threading
sys.path.insert(0, f"{LH}")

SQL_Q9_EXPLICIT = """select nation, o_year, sum(amount) as sum_profit from (
  select n_name as nation, extract(year from o_orderdate) as o_year,
    l_extendedprice * (1 - l_discount) - ps_supplycost * l_quantity as amount
  from lineitem
    join part on p_partkey = l_partkey
    join supplier on s_suppkey = l_suppkey
    join partsupp on ps_suppkey = l_suppkey and ps_partkey = l_partkey
    join orders on o_orderkey = l_orderkey
    join nation on s_nationkey = n_nationkey
  where p_name like '%green%') as profit
group by nation, o_year order by nation, o_year desc"""

def child(variant, sf):
    import polars as pl
    from engines import catalog
    from queries import TABLES, Q
    import polars_native as PN
    c = pl.col
    cat = catalog()
    fr = {t: pl.scan_iceberg(cat.load_table(f"sf{sf}.{t}")) for t in TABLES}

    def f64(lf):  # cast all decimals to Float64 at the scan
        sch = lf.collect_schema()
        return lf.with_columns([c(k).cast(pl.Float64) for k, v in sch.items() if isinstance(v, pl.Decimal)])

    if variant == "q9_default":
        lf = PN.q9(fr); res = lf.collect()
    elif variant == "q9_streaming":
        res = PN.q9(fr).collect(engine="streaming")
    elif variant == "q9_float":
        res = PN.q9({k: f64(v) for k, v in fr.items()}).collect()
    elif variant == "q9_reorder":
        # build-side reduction: filter part first, semi-join lineitem on the qualifying parts
        # before joining the wide tables, so the large hash tables are never built on lineitem
        p = fr["part"].filter(c("p_name").str.contains("green")).select("p_partkey")
        li = (fr["lineitem"].select("l_orderkey", "l_partkey", "l_suppkey", "l_quantity", "l_extendedprice", "l_discount")
              .join(p, left_on="l_partkey", right_on="p_partkey", how="semi"))
        ps = fr["partsupp"].select("ps_partkey", "ps_suppkey", "ps_supplycost").join(p, left_on="ps_partkey", right_on="p_partkey", how="semi")
        res = (li.join(ps, left_on=["l_partkey", "l_suppkey"], right_on=["ps_partkey", "ps_suppkey"])
               .join(fr["supplier"].select("s_suppkey", "s_nationkey"), left_on="l_suppkey", right_on="s_suppkey")
               .join(fr["orders"].select("o_orderkey", "o_orderdate"), left_on="l_orderkey", right_on="o_orderkey")
               .join(fr["nation"].select("n_nationkey", "n_name"), left_on="s_nationkey", right_on="n_nationkey")
               .select(c("n_name").alias("nation"), c("o_orderdate").dt.year().alias("o_year"),
                       (c("l_extendedprice") * (1 - c("l_discount")) - c("ps_supplycost") * c("l_quantity")).alias("amount"))
               .group_by("nation", "o_year").agg(c("amount").sum().alias("sum_profit"))
               .sort(["nation", "o_year"], descending=[False, True])).collect()
    elif variant == "q18_streaming":
        res = PN.q18(fr).collect(engine="streaming")
    elif variant == "q9_plan":
        print(PN.q9(fr).explain()); return
    elif variant == "sql_q9_plan":
        ctx = pl.SQLContext(fr, eager=False); print(ctx.execute(Q["q9"]).explain()); return
    elif variant in ("sql_q9_unopt_plan", "sql_q9_explicit_plan"):
        ctx = pl.SQLContext(fr, eager=False)
        if variant == "sql_q9_unopt_plan":
            print(ctx.execute(Q["q9"]).explain(optimized=False)); return
        sql = SQL_Q9_EXPLICIT
        print(ctx.execute(sql).explain()); return
    elif variant == "sql_q9_explicit":
        sql = SQL_Q9_EXPLICIT
        res = pl.SQLContext(fr, eager=False).execute(sql).collect()
    elif variant == "_unused":
        sql = """select nation, o_year, sum(amount) as sum_profit from (
          select n_name as nation, extract(year from o_orderdate) as o_year,
            l_extendedprice * (1 - l_discount) - ps_supplycost * l_quantity as amount
          from lineitem
            join part on p_partkey = l_partkey
            join supplier on s_suppkey = l_suppkey
            join partsupp on ps_suppkey = l_suppkey and ps_partkey = l_partkey
            join orders on o_orderkey = l_orderkey
            join nation on s_nationkey = n_nationkey
          where p_name like '%green%') as profit
        group by nation, o_year order by nation, o_year desc"""
        res = pl.SQLContext(fr, eager=False).execute(sql).collect()
    elif variant == "sql_q9_default":
        res = pl.SQLContext(fr, eager=False).execute(Q["q9"]).collect()
    else:
        raise SystemExit("unknown " + variant)
    print(json.dumps({"rows": res.height, "first": [str(x) for x in res.row(0)]}))

def parent(sf, variants, reps=3):
    import psutil
    out = []
    for v in variants:
        for r in range(reps):
            os.sync(); open("/proc/sys/vm/drop_caches", "w").write("3"); time.sleep(1)
            t0 = time.time()
            p = subprocess.Popen([sys.executable, __file__, v, str(sf)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            peak = 0
            while p.poll() is None:
                try:
                    pr = psutil.Process(p.pid); peak = max(peak, pr.memory_info().rss)
                except psutil.NoSuchProcess: pass
                time.sleep(0.05)
            so, se = p.communicate()
            rec = dict(variant=v, sf=sf, rep=r, rc=p.returncode, wall=time.time() - t0, peak_gb=peak / 2**30,
                       out=so.strip()[-300:], err=se.strip()[-200:] if p.returncode else "")
            print(json.dumps(rec), flush=True); out.append(rec)
            if p.returncode != 0 and r == 0 and "plan" not in v:
                break  # deterministic failure: do not repeat
    return out

if __name__ == "__main__":
    if sys.argv[1] == "run":
        res = parent(int(sys.argv[2]), sys.argv[3].split(","), int(sys.argv[4]) if len(sys.argv) > 4 else 3)
        os.makedirs(f"{LH}/results/diag", exist_ok=True)
        with open(f"{LH}/results/diag/diag_sf{sys.argv[2]}_{abs(hash(sys.argv[3]))%10**6}.json", "w") as f:
            json.dump(res, f, indent=1)
    else:
        child(sys.argv[1], int(sys.argv[2]))
