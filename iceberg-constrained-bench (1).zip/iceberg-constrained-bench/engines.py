"""Engine adapters. Each adapter exposes:
    open(sf)          -> set up session/catalog/views for scale factor sf
    run(sql) -> rows  -> execute one query, materialise result as list of tuples
    close()

All engines read the same Apache Iceberg snapshot:
  * DuckDB  : native iceberg extension, iceberg_scan(<current metadata.json>)
  * Polars  : pl.scan_iceberg(<PyIceberg table>)  (lazy, predicate/projection pushdown)
  * Spark   : the iceberg-spark-runtime jar could not be fetched (Maven egress blocked),
              so Spark reads the Parquet data files listed by the same Iceberg
              snapshot's scan plan (PyIceberg plan_files()). Snapshot semantics are
              identical; Iceberg-level file pruning is not available to Spark.
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import os, sys, threading

ROOT = f"{LH}"
os.environ.setdefault("SPARK_HOME", _os.environ.get("SPARK_HOME", "/opt/spark"))
sys.path.insert(0, _os.environ.get("PYSPARK_SRC", "/opt/pyspark-4.2.0"))

from queries import TABLES, Q


def catalog():
    from pyiceberg.catalog.sql import SqlCatalog
    return SqlCatalog("lh", uri=f"sqlite:///{ROOT}/catalog.db", warehouse=f"file://{ROOT}/warehouse")


class DuckDBEngine:
    name = "duckdb"

    def __init__(self, threads=2):
        self.threads = threads
        self.name = "duckdb" if threads == 2 else f"duckdb-{threads}t"

    def open(self, sf):
        import duckdb
        from duckdb_extensions import import_extension
        import_extension("iceberg")
        self.con = duckdb.connect()
        self.con.load_extension("iceberg")
        self.con.execute(f"SET threads={self.threads}")
        cat = catalog()
        for t in TABLES:
            m = cat.load_table(f"sf{sf}.{t}").metadata_location.replace("file://", "")
            self.con.execute(f"CREATE VIEW {t} AS SELECT * FROM iceberg_scan('{m}')")
        self._local = threading.local()

    def _cur(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = self.con.cursor(); self._local.c = c
        return c

    def run(self, qid):
        return self._cur().execute(Q[qid]).fetchall()

    def close(self):
        self.con.close()


class PolarsEngine:
    """sql=False: native LazyFrame plans (measured). sql=True: SQLContext front-end."""

    def __init__(self, sql=False, streaming=False, tuned=False):
        self.sql = sql
        self.streaming = streaming
        self.tuned = tuned
        self.name = "polars-sql" if sql else ("polars-stream" if streaming else ("polars-tuned" if tuned else "polars"))

    def open(self, sf):
        import polars as pl
        self.pl = pl
        cat = catalog()
        self.frames = {t: pl.scan_iceberg(cat.load_table(f"sf{sf}.{t}")) for t in TABLES}

    def run(self, qid):
        if self.sql:
            # A fresh SQLContext per call keeps concurrent callers independent.
            ctx = self.pl.SQLContext(self.frames, eager=False)
            return ctx.execute(Q[qid]).collect().rows()
        from polars_native import NATIVE, TUNED
        lf = (TUNED if self.tuned else NATIVE)[qid](self.frames)
        return (lf.collect(engine="streaming") if self.streaming else lf.collect()).rows()

    def close(self):
        pass


class SparkEngine:
    """mode = 'local'      : local[2], single JVM (driver = executor)
       mode = 'standalone' : client driver + standalone master + 2 workers x 1 core
                             on the same host (pseudo-distributed)."""

    def __init__(self, mode="local", tuned=False, stock=False):
        self.mode = mode
        self.tuned = tuned   # disk-frugal settings for the spill regime (SF32)
        self.stock = stock   # Spark defaults (200 shuffle partitions, FIFO); only driver memory raised to 4g
        self.name = ("spark-local-default" if stock else ("spark-local-tuned" if tuned else "spark-local")) if mode == "local" else "spark-cluster"

    def open(self, sf):
        from pyspark.sql import SparkSession
        b = SparkSession.builder.appName(f"bench-{self.name}-sf{sf}")
        if self.mode == "local":
            b = b.master("local[2]").config("spark.driver.memory", "4g")
        else:
            b = (b.master("spark://127.0.0.1:7077")
                  .config("spark.driver.memory", "1g")
                  .config("spark.executor.memory", "1400m")
                  .config("spark.executor.cores", "1")
                  .config("spark.cores.max", "2"))
        if not self.stock:
            b = (b.config("spark.sql.shuffle.partitions", "4")
                  .config("spark.sql.adaptive.enabled", "true")
                  .config("spark.scheduler.mode", "FAIR"))
        b = (b.config("spark.ui.enabled", "false")
              .config("spark.ui.showConsoleProgress", "false"))
        if self.tuned:
            b = (b.config("spark.io.compression.codec", "zstd")
                  .config("spark.cleaner.referenceTracking.blocking", "true")
                  .config("spark.cleaner.periodicGC.interval", "1min"))
        self.spark = b.getOrCreate()
        self.spark.sparkContext.setLogLevel("ERROR")
        cat = catalog()
        for t in TABLES:
            tbl = cat.load_table(f"sf{sf}.{t}")
            files = [ft.file.file_path.replace("file://", "") for ft in tbl.scan().plan_files()]
            self.spark.read.parquet(*files).createOrReplaceTempView(t)

    def run(self, qid):
        rows = [tuple(r) for r in self.spark.sql(Q[qid]).collect()]
        if self.tuned:   # drop references so the ContextCleaner deletes this query's shuffle files
            import gc; gc.collect(); self.spark.sparkContext._jvm.System.gc()
        return rows

    def close(self):
        self.spark.stop()


def make(name):
    return {"duckdb": DuckDBEngine, "polars": PolarsEngine,
            "duckdb-1t": lambda: DuckDBEngine(threads=1),
            "polars-sql": lambda: PolarsEngine(sql=True),
            "polars-stream": lambda: PolarsEngine(streaming=True),
            "polars-tuned": lambda: PolarsEngine(tuned=True),
            "spark-local": lambda: SparkEngine("local"),
            "spark-cluster": lambda: SparkEngine("standalone"),
            "spark-local-tuned": lambda: SparkEngine("local", tuned=True),
            "spark-local-default": lambda: SparkEngine("local", stock=True)}[name]()
