"""Analysis of benchmark runs -> tables (CSV/JSON) and colour figures (PDF).

Definitions
  warm latency   : wall time of a query in passes 1..3 of a session (process warm)
  cold latency   : first execution of the query in a fresh process after dropping the OS cache
  time-to-first-answer (TTFA): process launch -> first query (Q1) result, cold
  end-to-end job : process launch -> all 8 cold queries done (a one-off batch job)
  CPU-seconds    : busy CPU time (all cores, system-wide) inside the query window,
                   linearly interpolated from 0.2 s cumulative samples
  energy (J)     : Cloud Carbon Footprint linear model for AWS, attributed to the window:
                   E = PUE * [ vCPU*Pmin*t + (Pmax-Pmin)*cpu_s + Wmem*GB_used*t ]
                   Pmin=0.74 W, Pmax=3.5 W per vCPU, Wmem=0.392 W/GB, PUE=1.135, vCPU=2
  cost ($)       : t * price; price = m6i.large (2 vCPU, 8 GiB) on-demand, ap-south-1,
                   $0.101/h. All configurations ran on one such node.
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import json, glob, os, pickle, math, itertools
from collections import defaultdict
import numpy as np, pandas as pd

ROOT = f"{LH}"
RES = f"{ROOT}/results"; FIG = f"{ROOT}/figures"; os.makedirs(FIG, exist_ok=True)
PMIN, PMAX, WMEM, PUE, VCPU = 0.74, 3.5, 0.392, 1.135, 2
PRICE_H = 0.101
ENGINES = ["duckdb", "polars", "polars-stream", "polars-tuned", "spark-local", "spark-local-tuned", "spark-local-default", "spark-cluster", "duckdb-1t"]
LABEL = {"duckdb": "DuckDB", "polars": "Polars (in-memory)", "polars-stream": "Polars (streaming)", "polars-tuned": "Polars (in-memory, Q9 semi-join)",
         "spark-local": "Spark local[2]", "spark-local-tuned": "Spark local[2], disk-frugal", "spark-local-default": "Spark local[2], stock defaults", "duckdb-1t": "DuckDB, 1 thread", "spark-cluster": "Spark standalone (2 workers)"}
SHORT = {"duckdb": "DuckDB", "polars": "Polars-mem", "polars-stream": "Polars-stream", "polars-tuned": "Polars-mem+fix",
         "spark-local": "Spark-local", "spark-local-tuned": "Spark-local (frugal)", "spark-local-default": "Spark-local (stock)", "duckdb-1t": "DuckDB-1t", "spark-cluster": "Spark-cluster"}
COLOR = {"duckdb": "#E69F00", "polars": "#0072B2", "polars-stream": "#56B4E9", "polars-tuned": "#CC79A7",
         "spark-local": "#D55E00", "spark-local-tuned": "#D55E00", "spark-local-default": "#8C3B00", "duckdb-1t": "#B07800", "spark-cluster": "#009E73"}
MARK = {"duckdb": "o", "polars": "s", "polars-stream": "D", "polars-tuned": "P", "spark-local": "^", "spark-local-tuned": "<", "spark-local-default": ">", "duckdb-1t": "h", "spark-cluster": "v"}
from queries import ORDER, QCLASS


def load_runs():
    runs = []
    for f in sorted(glob.glob(f"{RES}/runs/*.json")):
        runs.append(json.load(open(f)))
    return runs


def interp_cpu(samples, t0, t1):
    ts = np.array([s[0] for s in samples]); cpu = np.array([s[2] for s in samples])
    if len(ts) < 2: return float("nan")
    return float(np.interp(t1, ts, cpu) - np.interp(t0, ts, cpu))


def window_max(samples, t0, t1, idx):
    vals = [s[idx] for s in samples if t0 - 0.2 <= s[0] <= t1 + 0.2 and len(s) > idx]
    return max(vals) if vals else float("nan")


def window_mean(samples, t0, t1, idx):
    vals = [s[idx] for s in samples if t0 - 0.2 <= s[0] <= t1 + 0.2 and len(s) > idx]
    return float(np.mean(vals)) if vals else float("nan")


def energy(t, cpu_s, mem_gb):
    return PUE * (VCPU * PMIN * t + (PMAX - PMIN) * cpu_s + WMEM * max(mem_gb, 0) * t)


def query_table(runs):
    rows = []
    for r in runs:
        if r["mode"] != "single": continue
        S = r["samples"]
        for e in r["events"]:
            if e.get("ev") != "q": continue
            t0, t1 = e["ts"], e["ts"] + e["s"]
            cpu = interp_cpu(S, t0, t1)
            mem = window_mean(S, t0, t1, 3) / 2**30 if len(S[0]) > 3 else window_mean(S, t0, t1, 1) / 2**30
            rows.append(dict(engine=r["engine"], sf=r["sf"], rep=r["rep"], q=e["q"], qclass=QCLASS[e["q"]],
                             phase=e["phase"], pass_=e["rep"], lat=e["s"], cpu_s=cpu,
                             util=min(cpu / e["s"], VCPU) if e["s"] > 0 else np.nan,
                             mem_gb=mem, energy_j=energy(e["s"], min(cpu, VCPU * e["s"]), mem),
                             cost_usd=e["s"] * PRICE_H / 3600))
    return pd.DataFrame(rows)


def run_table(runs):
    rows = []
    for r in runs:
        ev = r["events"]; S = r["samples"]
        get = lambda name: next((e for e in ev if e.get("ev") == name), None)
        ps, rd = get("proc_start"), get("ready")
        qs = [e for e in ev if e.get("ev") == "q"]
        cold = [e for e in qs if e.get("phase") == "cold"]
        rows.append(dict(run_id=r["run_id"], engine=r["engine"], sf=r["sf"], mode=r["mode"], arg=r["arg"],
                         rep=r["rep"], status=r["status"],
                         python_start_s=(ps["t"] - r["t_launch"]) if ps else np.nan,
                         open_s=rd["open_s"] if rd else np.nan,
                         ttfa_s=(cold[0]["ts"] + cold[0]["s"] - r["t_launch"]) if cold else np.nan,
                         e2e_job_s=(cold[-1]["ts"] + cold[-1]["s"] - r["t_launch"]) if len(cold) == 8 else np.nan,
                         daemon_start_s=r.get("daemon_start_s"),
                         peak_rss_gb=(max(s[3] for s in S) / 2**30) if S and len(S[0]) > 3 else np.nan,
                         peak_used_gb=(max(s[1] for s in S) / 2**30) if S else np.nan,
                         failed_at=(None if r["status"] == "ok" else
                                    next((q for q in ORDER if q not in [e["q"] for e in cold]), None))))
    return pd.DataFrame(rows)


def gmean(x):
    x = np.asarray(x, float); x = x[x > 0]
    return float(np.exp(np.mean(np.log(x)))) if len(x) else np.nan


def boot_gmean_ci(df, B=2000, seed=7):
    """Bootstrap CI of the geometric mean of per-query medians: resample observations within each query."""
    rng = np.random.default_rng(seed)
    groups = [g["lat"].values for _, g in df.groupby("q")]
    stats = []
    for _ in range(B):
        meds = [np.median(rng.choice(g, len(g), replace=True)) for g in groups]
        stats.append(gmean(meds))
    return np.percentile(stats, [2.5, 97.5])


# Energy-model sensitivity: Cloud Carbon Footprint coefficients for the three providers.
CCF_SETS = {"AWS": (0.74, 3.5, 1.135), "GCP": (0.71, 4.26, 1.1), "Azure": (0.78, 3.76, 1.185)}

def energy_set(t, cpu_s, mem_gb, pmin, pmax, pue):
    return pue * (VCPU * pmin * t + (pmax - pmin) * cpu_s + WMEM * max(mem_gb, 0) * t)
