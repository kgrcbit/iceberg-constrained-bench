#!/bin/bash
# Pseudo-distributed Spark standalone cluster on one host: 1 master + 2 workers (1 core, 1500 MB each)
export SPARK_HOME=${SPARK_HOME:-/opt/spark} SPARK_LOCAL_IP=127.0.0.1
mkdir -p $PWD/sparklogs
case "$1" in
 start)
  nohup $SPARK_HOME/bin/spark-class org.apache.spark.deploy.master.Master --host 127.0.0.1 --port 7077 --webui-port 8080 > $PWD/sparklogs/master.log 2>&1 &
  sleep 5
  for i in 1 2; do
    nohup $SPARK_HOME/bin/spark-class org.apache.spark.deploy.worker.Worker --cores 1 --memory 1500m --webui-port 808$i --work-dir $PWD/sparkwork$i spark://127.0.0.1:7077 > $PWD/sparklogs/worker$i.log 2>&1 &
  done
  sleep 6 ;;
 stop) pkill -f org.apache.spark.deploy.worker.Worker; pkill -f org.apache.spark.deploy.master.Master; sleep 2 ;;
esac
