"""Benchmark runner (parent process). For each run it:
  1. drops the OS page cache (disk-cold start),
  2. records a baseline of system memory in use,
  3. launches worker.py in a fresh process,
  4. samples system-wide memory-in-use and busy CPU-seconds every 0.2 s,
  5. writes events + samples to results/runs/<run_id>.json.

System-wide accounting is used for every engine so that JVM daemons, executors and
Python/Rust threads are all counted the same way on an otherwise idle host.
A run is marked OOM if the worker is killed by the kernel (cgroup limit ~6 GB).
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import sys, os, json, time, subprocess, threading, itertools
import psutil

ROOT = f"{LH}"
OUT = f"{ROOT}/results/runs"; os.makedirs(OUT, exist_ok=True)
ENV = dict(os.environ, SPARK_HOME=_os.environ.get("SPARK_HOME", "/opt/spark"), SPARK_LOCAL_IP="127.0.0.1",
           PYSPARK_PYTHON="python3", PYTHONWARNINGS="ignore")

def busy_cpu():
    c = psutil.cpu_times()
    return c.user + c.nice + c.system + c.irq + c.softirq + getattr(c, "steal", 0)

def mem_used():
    v = psutil.virtual_memory(); return v.total - v.available

def new_rss(base_pids, me):
    """Sum RSS (bytes) of all processes started after the baseline (worker, JVMs, daemons)."""
    tot = 0
    for pr in psutil.process_iter(["pid", "memory_info"]):
        if pr.info["pid"] in base_pids or pr.info["pid"] == me: continue
        mi = pr.info["memory_info"]
        if mi: tot += mi.rss
    return tot

def drop_caches():
    os.sync()
    with open("/proc/sys/vm/drop_caches", "w") as f: f.write("3")

def run(engine, sf, mode, arg, rep, timeout=7200):
    run_id = f"{engine}_sf{sf}_{mode}{arg}_r{rep}"
    path = f"{OUT}/{run_id}.json"
    if os.path.exists(path):
        print("skip", run_id); return
    if engine == "spark-cluster":
        subprocess.run([f"{ROOT}/cluster.sh", "stop"], capture_output=True)
    drop_caches(); time.sleep(2)
    base_mem = mem_used(); base_cpu = busy_cpu()
    base_pids = set(psutil.pids()); me = os.getpid()
    daemon_s = None
    if engine == "spark-cluster":   # daemons are part of this deployment's footprint
        t = time.time(); subprocess.run([f"{ROOT}/cluster.sh", "start"], capture_output=True, env=ENV)
        daemon_s = time.time() - t
    t_launch = time.time()
    p = subprocess.Popen([sys.executable, f"{ROOT}/worker.py", engine, str(sf), mode, str(arg), f"r{rep}"],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=ENV)
    samples, stop = [], threading.Event()
    def sampler():
        while not stop.is_set():
            samples.append((time.time(), mem_used() - base_mem, busy_cpu() - base_cpu, new_rss(base_pids, me)))
            time.sleep(0.2)
    th = threading.Thread(target=sampler, daemon=True); th.start()
    events = []; timed_out = False
    err_tail = []
    def read_err():
        for line in p.stderr: err_tail.append(line); del err_tail[:-40]
    te = threading.Thread(target=read_err, daemon=True); te.start()
    try:
        for line in p.stdout:
            try: events.append(json.loads(line))
            except Exception: pass
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill(); timed_out = True
    stop.set(); th.join(); te.join(timeout=2)
    rc = p.returncode
    status = "timeout" if timed_out else ("ok" if rc == 0 else ("oom" if rc in (-9, 137) else f"error{rc}"))
    if engine == "spark-cluster":
        subprocess.run([f"{ROOT}/cluster.sh", "stop"], capture_output=True)
    rec = dict(run_id=run_id, engine=engine, sf=sf, mode=mode, arg=arg, rep=rep, status=status,
               t_launch=t_launch, base_mem=base_mem, daemon_start_s=daemon_s, events=events, samples=samples,
               stderr_tail="".join(err_tail)[-3000:] if status != "ok" else "")
    with open(path, "w") as f: json.dump(rec, f)
    wall = time.time() - t_launch
    print(f"{run_id}: {status} wall={wall:.1f}s peak_mem={max([s[1] for s in samples] or [0])/2**30:.2f}GB peak_rss={max([s[3] for s in samples] or [0])/2**30:.2f}GB "
          f"cpu={samples[-1][2] if samples else 0:.1f}s", flush=True)

if __name__ == "__main__":
    # usage: runner.py ENGINE[,ENGINE] SF[,SF] MODE ARG[,ARG] REPS
    engines, sfs, mode, args, reps = sys.argv[1].split(","), [int(x) for x in sys.argv[2].split(",")], \
        sys.argv[3], [int(x) for x in sys.argv[4].split(",")], int(sys.argv[5])
    for rep, sf, eng, a in itertools.product(range(1, reps + 1), sfs, engines, args):
        run(eng, sf, mode, a, rep)
