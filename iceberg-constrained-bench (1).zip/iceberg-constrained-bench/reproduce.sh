#!/usr/bin/env bash
# Full reproduction of the study. Run from the repository root on a Linux host
# (2 vCPUs, 8 GB RAM, ~6 GB cgroup memory limit, >= 60 GB free disk).
# Requires root for dropping the page cache (runner.py writes /proc/sys/vm/drop_caches).
set -euo pipefail
cd "$(dirname "$0")"
export LH_ROOT="$PWD"
: "${SPARK_HOME:?set SPARK_HOME to an Apache Spark 4.2.0 distribution}"
: "${PYSPARK_SRC:?set PYSPARK_SRC to the pyspark-4.2.0 source directory}"

# 1. Data: TPC-H SF1-8 via tpchgen-cli, loaded into Iceberg (PyIceberg SqlCatalog)
for sf in 1 2 4 8; do
  tpchgen-cli -s "$sf" --format parquet --output-dir "raw/sf$sf"
done
python3 load_iceberg.py 1 2 4 8
# SF16 and SF32 are generated and loaded part by part (bounded disk use)
python3 load_large.py 16 32

# 2. Experiments (each run is a fresh process; results/runs/*.json)
bash scripts/run_all.sh          # Exp. A: DuckDB, Polars, Spark-local, Spark co-located (co-located Spark uses ./cluster.sh)
bash scripts/run_extra.sh        # Polars streaming
bash scripts/run_fix1.sh         # Exp. B: Polars Q9 semi-join rewrite
bash scripts/run_cost.sh         # single-threaded DuckDB (COST baseline)
bash scripts/run_large.sh        # SF16 / SF32 extension
bash scripts/run_rev2.sh         # Spark-stock and Spark disk-frugal (SF1, SF8)
bash scripts/run_rev2b.sh        # Spark-stock to 3 processes at SF1-8

# 3. Analysis (tables, mixed models, contrasts, feasibility, energy checks, figures)
python3 analyze.py
python3 discussion_calcs.py
python3 stats_rev2.py
python3 correctness_ref.py
python3 figs_rev2.py
python3 env_manifest.py
