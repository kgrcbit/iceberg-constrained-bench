"""How much would Iceberg manifest/file-level pruning save for each query's table predicates?
Uses PyIceberg's planner (manifest partition + column min/max statistics) on the real snapshots."""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import json, sys
sys.path.insert(0, f"{LH}")
from engines import catalog
from pyiceberg.expressions import And, GreaterThanOrEqual, LessThan, LessThanOrEqual, GreaterThan, EqualTo
from datetime import date
cat = catalog()
D = lambda y, m, d: date(y, m, d).isoformat()
PRED = {  # predicates that the queries apply directly to a base table (pushdown candidates)
 ("q1", "lineitem"): LessThanOrEqual("l_shipdate", D(1998, 9, 2)),
 ("q3", "orders"): LessThan("o_orderdate", D(1995, 3, 15)),
 ("q3", "lineitem"): GreaterThan("l_shipdate", D(1995, 3, 15)),
 ("q3", "customer"): EqualTo("c_mktsegment", "BUILDING"),
 ("q5", "orders"): And(GreaterThanOrEqual("o_orderdate", D(1994, 1, 1)), LessThan("o_orderdate", D(1995, 1, 1))),
 ("q6", "lineitem"): And(GreaterThanOrEqual("l_shipdate", D(1994, 1, 1)), LessThan("l_shipdate", D(1995, 1, 1))),
 ("q10", "orders"): And(GreaterThanOrEqual("o_orderdate", D(1993, 10, 1)), LessThan("o_orderdate", D(1994, 1, 1))),
 ("q10", "lineitem"): EqualTo("l_returnflag", "R"),
}
out = []
for sf in [1, 2, 4, 8]:
    for (q, t), pred in PRED.items():
        tbl = cat.load_table(f"sf{sf}.{t}")
        allf = list(tbl.scan().plan_files()); kept = list(tbl.scan(row_filter=pred).plan_files())
        ab = sum(f.file.file_size_in_bytes for f in allf); kb = sum(f.file.file_size_in_bytes for f in kept)
        out.append(dict(sf=sf, q=q, table=t, files=len(allf), files_kept=len(kept), bytes_pruned_pct=100 * (1 - kb / ab)))
        print(out[-1])
json.dump(out, open(f"{LH}/results/pruning.json", "w"), indent=1)
