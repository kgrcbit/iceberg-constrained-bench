"""Write ENVIRONMENT.md: the execution environment needed to reproduce the study (reviewer minor comment 7)."""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import subprocess, platform, json, os, sys
sys.path.insert(0, f"{LH}")
def sh(c):
    try: return subprocess.run(c, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception as e: return f"n/a ({e})"
import duckdb, polars as pl, pyarrow, pyiceberg
from queries import Q, ORDER
L = []
L += ["# Execution environment", ""]
L += ["| Item | Value |", "|---|---|"]
rows = [
 ("OS", sh("grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '\"'")),
 ("Kernel", platform.release()),
 ("Virtualization", "Firecracker micro-VM (KVM); no RAPL/MSR/hwmon"),
 ("CPU model", sh("grep -m1 'model name' /proc/cpuinfo | cut -d: -f2").strip()),
 ("vCPUs", str(os.cpu_count())),
 ("RAM", sh("free -m | awk '/Mem:/{printf \"%.1f GiB (%d MiB)\", $2/1024, $2}'")),
 ("cgroup memory limit", "cgroup v1 memory.limit_in_bytes = " + sh("cat /sys/fs/cgroup/memory$(grep memory: /proc/self/cgroup | cut -d: -f3)/memory.limit_in_bytes") + " bytes (5.84 GiB) on the benchmark process group's cgroup; exceeding it triggers the kernel OOM killer"),
 ("Disk / filesystem", sh("findmnt -no SOURCE,FSTYPE,OPTIONS / | head -1")),
 ("Python", platform.python_version()),
 ("DuckDB", f"{duckdb.__version__} (git {getattr(duckdb, '__git_revision__', 'n/a')}); extensions iceberg 45163a28, avro f9d5902, tpch v1.5.5"),
 ("Polars", f"{pl.__version__} (PyPI wheel; build commit not exposed by the wheel)"),
 ("PyArrow", pyarrow.__version__),
 ("PyIceberg", pyiceberg.__version__),
 ("Apache Spark", "4.2.0 (PyPI source distribution, bundled jars)"),
 ("Java", sh("java -version 2>&1 | grep -v Picked | head -1")),
 ("JVM flags (driver)", "-Xmx4g (local), -Xmx1g driver / 1400m executors (co-located standalone); Spark default JVM options otherwise"),
 ("Spark-local (Exp. A)", "local[2]; spark.driver.memory=4g; spark.sql.shuffle.partitions=4; spark.sql.adaptive.enabled=true; spark.scheduler.mode=FAIR; spark.ui.enabled=false"),
 ("Spark-stock (Exp. A)", "local[2]; spark.driver.memory=4g; all other settings at Spark 4.2.0 defaults (200 shuffle partitions, AQE on, FIFO)"),
 ("Spark disk-frugal (Exp. B)", "Spark-local settings plus spark.io.compression.codec=zstd, spark.cleaner.referenceTracking.blocking=true, spark.cleaner.periodicGC.interval=1min, explicit JVM GC after each query"),
 ("Spark co-located standalone (Exp. A)", "master + 2 workers (1 core, 1500m each) on the same VM; executors 1400m, driver 1g, spark.cores.max=2"),
 ("Environment variables", "SPARK_HOME=<Spark 4.2.0 jars>; SPARK_LOCAL_IP=127.0.0.1; PYSPARK_PYTHON=python3; PYTHONWARNINGS=ignore"),
 ("Container image", "none (bare VM); package installation commands listed below"),
 ("Data generation", "tpchgen-cli -s {SF} --format parquet (SF1-8); SF16/32 part-wise via load_large.py (--parts/--part); deterministic, no random seed"),
 ("Iceberg loading", "PyIceberg SqlCatalog (SQLite), appends of ~4M rows, Parquet zstd, write.target-file-size-bytes=268435456"),
 ("Random seeds", "bootstrap: numpy default_rng(7) (rev 1) and default_rng(20261003) (rev 2); workloads are deterministic"),
]
L += [f"| {a} | {b} |" for a, b in rows]
L += ["", "## Package installation", "```", "pip install duckdb==1.5.5 duckdb_extension_iceberg==1.5.5 duckdb_extension_avro duckdb_extension_tpch polars==1.44.2 'pyiceberg[sql-sqlite,pyarrow]'==0.12.0 tpchgen-cli psutil statsmodels scipy pandas matplotlib", "pip download --no-binary :all: pyspark==4.2.0  # jars taken from deps/", "```", ""]
L += ["## Query texts (SQL engines)", ""]
for q in ORDER:
    L += [f"### {q.upper()}", "```sql", Q[q].strip(), "```", ""]
L += ["Polars native LazyFrame plans: see polars_native.py (NATIVE; TUNED replaces Q9 with q9_semi).", ""]
L += ["## Iceberg metadata", "Current metadata.json paths per table are recorded in load_log_*.json; the warehouse directory layout is warehouse/sf{SF}/{table}/{metadata,data}."]
open(f"{LH}/ENVIRONMENT.md", "w").write("\n".join(L) + "\n")
print("\n".join(L[:32]))
