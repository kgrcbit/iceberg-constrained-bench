"""TPC-H queries used in the study (8 of 22), with TPC-H validation substitution
parameters. Date arithmetic is pre-computed into literals so that the identical SQL
text runs unmodified on DuckDB, Polars SQL and Spark SQL.

Query classes:
  scan-aggregate : Q1, Q6
  multi-join     : Q3, Q5, Q9, Q10
  high-cardinality / outer-join / subquery : Q13, Q18
"""
QCLASS = {"q1": "scan-agg", "q6": "scan-agg",
          "q3": "join", "q5": "join", "q9": "join", "q10": "join",
          "q13": "highcard", "q18": "highcard"}

Q = {}
Q["q1"] = """
select l_returnflag, l_linestatus,
  sum(l_quantity) as sum_qty, sum(l_extendedprice) as sum_base_price,
  sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
  sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
  avg(l_quantity) as avg_qty, avg(l_extendedprice) as avg_price,
  avg(l_discount) as avg_disc, count(*) as count_order
from lineitem
where l_shipdate <= date '1998-09-02'
group by l_returnflag, l_linestatus
order by l_returnflag, l_linestatus"""

Q["q3"] = """
select l_orderkey, sum(l_extendedprice * (1 - l_discount)) as revenue,
  o_orderdate, o_shippriority
from customer, orders, lineitem
where c_mktsegment = 'BUILDING' and c_custkey = o_custkey and l_orderkey = o_orderkey
  and o_orderdate < date '1995-03-15' and l_shipdate > date '1995-03-15'
group by l_orderkey, o_orderdate, o_shippriority
order by revenue desc, o_orderdate, l_orderkey
limit 10"""

Q["q5"] = """
select n_name, sum(l_extendedprice * (1 - l_discount)) as revenue
from customer, orders, lineitem, supplier, nation, region
where c_custkey = o_custkey and l_orderkey = o_orderkey and l_suppkey = s_suppkey
  and c_nationkey = s_nationkey and s_nationkey = n_nationkey
  and n_regionkey = r_regionkey and r_name = 'ASIA'
  and o_orderdate >= date '1994-01-01' and o_orderdate < date '1995-01-01'
group by n_name
order by revenue desc"""

Q["q6"] = """
select sum(l_extendedprice * l_discount) as revenue
from lineitem
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1995-01-01'
  and l_discount between 0.05 and 0.07 and l_quantity < 24"""

Q["q9"] = """
select nation, o_year, sum(amount) as sum_profit
from (
  select n_name as nation, extract(year from o_orderdate) as o_year,
    l_extendedprice * (1 - l_discount) - ps_supplycost * l_quantity as amount
  from part, supplier, lineitem, partsupp, orders, nation
  where s_suppkey = l_suppkey and ps_suppkey = l_suppkey and ps_partkey = l_partkey
    and p_partkey = l_partkey and o_orderkey = l_orderkey and s_nationkey = n_nationkey
    and p_name like '%green%'
) as profit
group by nation, o_year
order by nation, o_year desc"""

Q["q10"] = """
select c_custkey, c_name, sum(l_extendedprice * (1 - l_discount)) as revenue,
  c_acctbal, n_name, c_address, c_phone, c_comment
from customer, orders, lineitem, nation
where c_custkey = o_custkey and l_orderkey = o_orderkey
  and o_orderdate >= date '1993-10-01' and o_orderdate < date '1994-01-01'
  and l_returnflag = 'R' and c_nationkey = n_nationkey
group by c_custkey, c_name, c_acctbal, c_phone, n_name, c_address, c_comment
order by revenue desc, c_custkey
limit 20"""

Q["q13"] = """
select c_count, count(*) as custdist
from (
  select c_custkey, count(o_orderkey) as c_count
  from customer left outer join orders
    on c_custkey = o_custkey and o_comment not like '%special%requests%'
  group by c_custkey
) as c_orders
group by c_count
order by custdist desc, c_count desc"""

Q["q18"] = """
select c_name, c_custkey, o_orderkey, o_orderdate, o_totalprice, sum(l_quantity) as sum_qty
from customer, orders, lineitem
where o_orderkey in (
    select l_orderkey from lineitem group by l_orderkey having sum(l_quantity) > 300)
  and c_custkey = o_custkey and o_orderkey = l_orderkey
group by c_name, c_custkey, o_orderkey, o_orderdate, o_totalprice
order by o_totalprice desc, o_orderdate, o_orderkey
limit 100"""

ORDER = ["q1", "q3", "q5", "q6", "q9", "q10", "q13", "q18"]
TABLES = ["region", "nation", "supplier", "customer", "part", "partsupp", "orders", "lineitem"]
