"""Quantities used in the Analytical Discussion section (all from measured data)."""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import json, numpy as np, pandas as pd, sys
sys.path.insert(0, f"{LH}")
R = f"{LH}/results"
M = pd.read_csv(f"{R}/warm_query_medians.csv")
out = {}
gm = lambda x: float(np.exp(np.mean(np.log(x))))
# 1. COST: Spark-local (2 cores) vs single-threaded DuckDB; DuckDB parallel speed-up 1->2 threads
for sf in [1, 2, 4, 8]:
    d1 = M[(M.engine == "duckdb-1t") & (M.sf == sf)].set_index("q").lat
    d2 = M[(M.engine == "duckdb") & (M.sf == sf)].set_index("q").lat
    sp = M[(M.engine == "spark-local") & (M.sf == sf)].set_index("q").lat
    out[f"cost_sf{sf}"] = dict(spark2_over_duck1=gm(sp / d1), min=float((sp / d1).min()), max=float((sp / d1).max()),
                               duck_1to2_speedup=gm(d1 / d2))
# 2. fixed + proportional model t = a + c*SF per query (SF1-8, warm medians)
fx = {}
for e in ["duckdb", "polars-stream", "spark-local", "spark-cluster"]:
    rows = []
    for q, g in M[(M.engine == e) & (M.sf <= 8)].groupby("q"):
        c, a = np.polyfit(g.sf, g.lat, 1)
        t1 = a + c; t8 = a + 8 * c
        rows.append(dict(q=q, a=a, c=c, fixed_share_sf1=a / t1, local_slope_sf8=8 * c / t8))
    df = pd.DataFrame(rows)
    fx[e] = dict(a_median=float(df.a.median()), a_min=float(df.a.min()), a_max=float(df.a.max()),
                 fixed_share_sf1_median=float(df.fixed_share_sf1.median()),
                 local_slope_sf8_median=float(df.local_slope_sf8.median()), c_median=float(df.c.median()))
out["fixed_cost_model"] = fx
# 3. Q9 lineitem projection bytes at SF8 (3 x int64 + 3 x decimal128)
rows8 = 47989007
out["q9_lineitem_proj_gib_sf8"] = rows8 * (3 * 8 + 3 * 16) / 2**30
out["q9_orders_proj_gib_sf8"] = 12_000_000 * (8 + 4) / 2**30
# 4. cross-join threshold for 2^32 rows
import polars as pl
from engines import catalog
cat = catalog()
green = {sf: pl.scan_iceberg(cat.load_table(f"sf{sf}.part")).filter(pl.col("p_name").str.contains("green")).select(pl.len()).collect().item() for sf in [1, 8]}
supp = {1: 10000, 8: 80000}
out["green_parts"] = green
out["crossjoin_rows"] = {sf: green[sf] * supp[sf] for sf in green}
k = green[1] * supp[1]   # rows at SF1, grows ~SF^2
out["crossjoin_sf_threshold_2pow32"] = float(np.sqrt(2**32 / k))
# 5. cost & energy per 1000 one-off 8-query jobs (process launch -> last cold answer)
E = pd.read_csv(f"{R}/e2e.csv"); PRICE = 0.101
tab = []
for _, r in E.iterrows():
    tab.append(dict(engine=r.engine, sf=int(r.sf), e2e_s=r.e2e, usd_per_1000_jobs=r.e2e * PRICE / 3600 * 1000))
out["job_cost"] = tab
# H2: fixed-overhead share of one-off job time = (interpreter + session open + sum of positive per-query fixed terms) / e2e
E2 = pd.read_csv(f"{R}/e2e.csv"); h2 = {}
for e in ["spark-local", "spark-cluster", "duckdb", "polars-stream"]:
    a_sum = 0.0; cs = []
    for q, g in M[(M.engine == e) & (M.sf <= 8)].groupby("q"):
        c, a = np.polyfit(g.sf, g.lat, 1); a_sum += max(a, 0.0); cs.append(c)
    for sf in (1, 8):
        r = E2[(E2.engine == e) & (E2.sf == sf)].iloc[0]
        dmn = 0.0 if pd.isna(r.daemon) else float(r.daemon)
        fixed = float(r.python_start + r.open + a_sum + dmn)
        h2[f"{e}_sf{sf}"] = dict(fixed_s=fixed, share=fixed / float(r.e2e + dmn))
    h2[f"{e}_c_median"] = float(np.median(cs))
out["h2"] = h2
json.dump(out, open(f"{R}/discussion_calcs.json", "w"), indent=1, default=float)
print(json.dumps({k: v for k, v in out.items() if k != "job_cost"}, indent=1, default=float))
jc = pd.DataFrame(tab); print(jc[jc.engine.isin(["duckdb", "spark-local", "spark-local-tuned", "polars-stream"])].round(3).to_string())
