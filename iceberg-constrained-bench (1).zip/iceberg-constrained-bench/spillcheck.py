"""Does DuckDB spill to disk at SF32? Run Q9 and Q18 with the default configuration and
record the size of DuckDB's temp directory and the engine's own memory accounting."""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import sys, os, time, json, threading, shutil, subprocess
sys.path.insert(0, f"{LH}")
import duckdb
from duckdb_extensions import import_extension
from engines import catalog
from queries import TABLES, Q
import psutil
TMP = f"{LH}/duck_tmp"; shutil.rmtree(TMP, ignore_errors=True); os.makedirs(TMP)
import_extension("iceberg"); con = duckdb.connect(); con.load_extension("iceberg")
con.execute("SET threads=2"); con.execute(f"SET temp_directory='{TMP}'")
print("memory_limit", con.sql("select current_setting('memory_limit')").fetchone()[0])
cat = catalog()
for t in TABLES:
    con.execute(f"CREATE VIEW {t} AS SELECT * FROM iceberg_scan('{cat.load_table('sf32.'+t).metadata_location.replace('file://','')}')")
def du(p):
    return sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(p) for f in fs)
out = {}
for q in ["q9", "q18", "q1"]:
    peak_tmp = 0; peak_rss = 0; stop = False
    def mon():
        global peak_tmp, peak_rss
        while not stop:
            peak_tmp = max(peak_tmp, du(TMP)); peak_rss = max(peak_rss, psutil.Process().memory_info().rss); time.sleep(0.1)
    th = threading.Thread(target=mon); th.start()
    t = time.time(); con.execute(Q[q]).fetchall(); d = time.time() - t
    stop = True; th.join()
    out[q] = dict(s=round(d, 1), peak_tmp_mb=round(peak_tmp / 2**20, 1), peak_rss_gb=round(peak_rss / 2**30, 2))
    print(q, out[q], flush=True)
json.dump(out, open(f"{LH}/results/duckdb_spillcheck_sf32.json", "w"), indent=1)
