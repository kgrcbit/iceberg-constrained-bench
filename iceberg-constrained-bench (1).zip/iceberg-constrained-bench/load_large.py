"""Generate and load large TPC-H scale factors part by part, so raw Parquet never exceeds one part on disk.
Same Iceberg settings as load_iceberg.py (zstd, 256 MB target files, ~4M-row appends)."""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import os, sys, time, json, subprocess, shutil, glob
import pyarrow as pa, pyarrow.parquet as pq
from pyiceberg.catalog.sql import SqlCatalog

ROOT = f"{LH}"; TMP = f"{ROOT}/rawtmp"
cat = SqlCatalog("lh", uri=f"sqlite:///{ROOT}/catalog.db", warehouse=f"file://{ROOT}/warehouse")
TABLES = ["region", "nation", "supplier", "customer", "part", "partsupp", "orders", "lineitem"]
PARTS = {"lineitem": 16, "orders": 4, "partsupp": 4, "customer": 1, "part": 1, "supplier": 1, "nation": 1, "region": 1}
BATCH = 4_000_000

def load(sf):
    ns = f"sf{sf}"
    if ns not in [n[0] for n in cat.list_namespaces()]: cat.create_namespace(ns)
    log = {}
    for t in TABLES:
        ident = f"{ns}.{t}"
        if cat.table_exists(ident): cat.drop_table(ident)
        tbl = None; rows = 0; t0 = time.time()
        nparts = PARTS[t] if t not in ("nation", "region") else 1
        for k in range(1, nparts + 1):
            shutil.rmtree(TMP, ignore_errors=True)
            cmd = ["tpchgen-cli", "-s", str(sf), "--format", "parquet", f"--tables={t}", "--output-dir", TMP]
            if nparts > 1: cmd += [f"--parts={nparts}", f"--part={k}"]
            subprocess.run(cmd, check=True, capture_output=True)
            for fpath in sorted(glob.glob(f"{TMP}/**/*.parquet", recursive=True)):
                pf = pq.ParquetFile(fpath)
                if tbl is None:
                    tbl = cat.create_table(ident, schema=pf.schema_arrow,
                        properties={"write.parquet.compression-codec": "zstd",
                                    "write.target-file-size-bytes": str(256 * 1024 * 1024)})
                buf, n = [], 0
                for b in pf.iter_batches(batch_size=500_000):
                    buf.append(b); n += b.num_rows
                    if n >= BATCH:
                        tbl.append(pa.Table.from_batches(buf, schema=pf.schema_arrow)); rows += n; buf, n = [], 0
                if buf: tbl.append(pa.Table.from_batches(buf, schema=pf.schema_arrow)); rows += n
        shutil.rmtree(TMP, ignore_errors=True)
        log[t] = {"rows": rows, "load_s": round(time.time() - t0, 1), "snapshots": len(tbl.refresh().snapshots())}
        print(sf, t, log[t], flush=True)
    json.dump(log, open(f"{ROOT}/load_log_sf{sf}.json", "w"), indent=1)

if __name__ == "__main__":
    for sf in [int(x) for x in sys.argv[1:]]: load(sf)
