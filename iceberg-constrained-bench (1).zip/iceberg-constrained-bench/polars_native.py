"""Native Polars LazyFrame implementations of the 8 TPC-H queries.

Rationale: Polars' SQL front-end turns implicit comma joins into cross joins that
are only partially rewritten; Q9 at SF1 exceeded the 6 GB memory limit through
SQLContext (recorded as a finding). The native lazy API is the way Polars itself
benchmarks TPC-H (pola-rs/polars-benchmark), so it is used for all measurements.
Semantics, parameters and output columns follow queries.py exactly.
"""
from datetime import date
import polars as pl

c = pl.col


def rev():
    return c("l_extendedprice") * (1 - c("l_discount"))


def q1(t):
    li = t["lineitem"]
    return (li.filter(c("l_shipdate") <= date(1998, 9, 2))
            .group_by("l_returnflag", "l_linestatus")
            .agg(c("l_quantity").sum().alias("sum_qty"),
                 c("l_extendedprice").sum().alias("sum_base_price"),
                 rev().sum().alias("sum_disc_price"),
                 (rev() * (1 + c("l_tax"))).sum().alias("sum_charge"),
                 c("l_quantity").mean().alias("avg_qty"),
                 c("l_extendedprice").mean().alias("avg_price"),
                 c("l_discount").mean().alias("avg_disc"),
                 pl.len().alias("count_order"))
            .sort("l_returnflag", "l_linestatus"))


def q3(t):
    cu = t["customer"].filter(c("c_mktsegment") == "BUILDING")
    o = t["orders"].filter(c("o_orderdate") < date(1995, 3, 15))
    li = t["lineitem"].filter(c("l_shipdate") > date(1995, 3, 15))
    return (cu.join(o, left_on="c_custkey", right_on="o_custkey")
            .join(li, left_on="o_orderkey", right_on="l_orderkey")
            .group_by(c("o_orderkey").alias("l_orderkey"), "o_orderdate", "o_shippriority")
            .agg(rev().sum().alias("revenue"))
            .select("l_orderkey", "revenue", "o_orderdate", "o_shippriority")
            .sort(["revenue", "o_orderdate", "l_orderkey"], descending=[True, False, False])
            .head(10))


def q5(t):
    r = t["region"].filter(c("r_name") == "ASIA")
    o = t["orders"].filter((c("o_orderdate") >= date(1994, 1, 1)) & (c("o_orderdate") < date(1995, 1, 1)))
    return (r.join(t["nation"], left_on="r_regionkey", right_on="n_regionkey")
            .join(t["customer"], left_on="n_nationkey", right_on="c_nationkey")
            .join(o, left_on="c_custkey", right_on="o_custkey")
            .join(t["lineitem"], left_on="o_orderkey", right_on="l_orderkey")
            .join(t["supplier"], left_on=["l_suppkey", "n_nationkey"], right_on=["s_suppkey", "s_nationkey"])
            .group_by("n_name").agg(rev().sum().alias("revenue"))
            .sort("revenue", descending=True))


def q6(t):
    return (t["lineitem"]
            .filter((c("l_shipdate") >= date(1994, 1, 1)) & (c("l_shipdate") < date(1995, 1, 1))
                    & c("l_discount").is_between(0.05, 0.07) & (c("l_quantity") < 24))
            .select((c("l_extendedprice") * c("l_discount")).sum().alias("revenue")))


def q9(t):
    p = t["part"].filter(c("p_name").str.contains("green"))
    return (p.join(t["partsupp"], left_on="p_partkey", right_on="ps_partkey")
            .join(t["supplier"], left_on="ps_suppkey", right_on="s_suppkey")
            .join(t["lineitem"], left_on=["p_partkey", "ps_suppkey"], right_on=["l_partkey", "l_suppkey"])
            .join(t["orders"], left_on="l_orderkey", right_on="o_orderkey")
            .join(t["nation"], left_on="s_nationkey", right_on="n_nationkey")
            .select(c("n_name").alias("nation"), c("o_orderdate").dt.year().alias("o_year"),
                    (rev() - c("ps_supplycost") * c("l_quantity")).alias("amount"))
            .group_by("nation", "o_year").agg(c("amount").sum().alias("sum_profit"))
            .sort(["nation", "o_year"], descending=[False, True]))


def q10(t):
    o = t["orders"].filter((c("o_orderdate") >= date(1993, 10, 1)) & (c("o_orderdate") < date(1994, 1, 1)))
    li = t["lineitem"].filter(c("l_returnflag") == "R")
    return (t["customer"].join(o, left_on="c_custkey", right_on="o_custkey")
            .join(li, left_on="o_orderkey", right_on="l_orderkey")
            .join(t["nation"], left_on="c_nationkey", right_on="n_nationkey")
            .group_by("c_custkey", "c_name", "c_acctbal", "c_phone", "n_name", "c_address", "c_comment")
            .agg(rev().sum().alias("revenue"))
            .select("c_custkey", "c_name", "revenue", "c_acctbal", "n_name", "c_address", "c_phone", "c_comment")
            .sort(["revenue", "c_custkey"], descending=[True, False])
            .head(20))


def q13(t):
    o = t["orders"].filter(~c("o_comment").str.contains("special.*requests"))
    return (t["customer"].join(o, left_on="c_custkey", right_on="o_custkey", how="left")
            .group_by("c_custkey").agg(c("o_orderkey").count().alias("c_count"))
            .group_by("c_count").agg(pl.len().alias("custdist"))
            .sort(["custdist", "c_count"], descending=[True, True]))


def q18(t):
    big = (t["lineitem"].group_by("l_orderkey").agg(c("l_quantity").sum().alias("s"))
           .filter(c("s") > 300).select("l_orderkey"))
    o = t["orders"].join(big, left_on="o_orderkey", right_on="l_orderkey", how="semi")
    return (t["customer"].join(o, left_on="c_custkey", right_on="o_custkey")
            .join(t["lineitem"], left_on="o_orderkey", right_on="l_orderkey")
            .group_by("c_name", c("c_custkey"), "o_orderkey", "o_orderdate", "o_totalprice")
            .agg(c("l_quantity").sum().alias("sum_qty"))
            .sort(["o_totalprice", "o_orderdate", "o_orderkey"], descending=[True, False, False])
            .head(100))


NATIVE = {"q1": q1, "q3": q3, "q5": q5, "q6": q6, "q9": q9, "q10": q10, "q13": q13, "q18": q18}


def q9_semi(t):
    """Q9 with manual semi-join reduction: restrict lineitem and partsupp to 'green' parts
    before the wide joins, so no hash table or materialised side holds all of lineitem.
    Same result as q9 (verified against DuckDB); used by the 'polars-tuned' configuration."""
    p = t["part"].filter(c("p_name").str.contains("green")).select("p_partkey")
    li = (t["lineitem"].select("l_orderkey", "l_partkey", "l_suppkey", "l_quantity", "l_extendedprice", "l_discount")
          .join(p, left_on="l_partkey", right_on="p_partkey", how="semi"))
    ps = (t["partsupp"].select("ps_partkey", "ps_suppkey", "ps_supplycost")
          .join(p, left_on="ps_partkey", right_on="p_partkey", how="semi"))
    return (li.join(ps, left_on=["l_partkey", "l_suppkey"], right_on=["ps_partkey", "ps_suppkey"])
            .join(t["supplier"].select("s_suppkey", "s_nationkey"), left_on="l_suppkey", right_on="s_suppkey")
            .join(t["orders"].select("o_orderkey", "o_orderdate"), left_on="l_orderkey", right_on="o_orderkey")
            .join(t["nation"].select("n_nationkey", "n_name"), left_on="s_nationkey", right_on="n_nationkey")
            .select(c("n_name").alias("nation"), c("o_orderdate").dt.year().alias("o_year"),
                    (rev() - c("ps_supplycost") * c("l_quantity")).alias("amount"))
            .group_by("nation", "o_year").agg(c("amount").sum().alias("sum_profit"))
            .sort(["nation", "o_year"], descending=[False, True]))


TUNED = dict(NATIVE, q9=q9_semi)
