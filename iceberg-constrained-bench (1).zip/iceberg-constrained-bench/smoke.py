import sys, time
from engines import make
from queries import Q, ORDER
e = make(sys.argv[1]); t=time.time(); e.open(int(sys.argv[2])); print('open', round(time.time()-t,2))
for q in ORDER:
    t=time.time()
    try:
        r = e.run(q); print(q, round(time.time()-t,2), len(r), r[0][:4] if r else None, flush=True)
    except Exception as x: print(q, 'ERR', str(x)[:300], flush=True)
e.close()
