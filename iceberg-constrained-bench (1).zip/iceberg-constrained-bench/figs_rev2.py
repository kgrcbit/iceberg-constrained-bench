"""Revision-2 figures: scaling with run-level CIs (Experiment A) and a feasibility matrix."""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import json, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import sys; sys.path.insert(0, f"{LH}")
from analysis_lib import COLOR, MARK, SHORT

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                     "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 6.4, "xtick.labelsize": 7, "ytick.labelsize": 7,
                     "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42,
                     "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
R = f"{LH}/results/rev2"; FIG = f"{LH}/figures"; W1 = 3.45
A = ["duckdb", "polars", "polars-stream", "spark-local-default", "spark-local", "spark-cluster"]
SHORT2 = dict(SHORT); SHORT2["spark-cluster"] = "Spark co-located"; SHORT2["spark-local-default"] = "Spark-stock"
CS = pd.read_csv(f"{R}/cell_summary.csv")

# ---------- Fig: scaling, Experiment A, run-level t intervals; extension cells hollow ----------
from matplotlib.ticker import LogLocator, FuncFormatter, NullFormatter
fig, ax = plt.subplots(figsize=(W1, 2.45))
for e in A:
    d = CS[CS.engine == e].sort_values("sf")
    if not len(d): continue
    ax.plot(d.sf, d.gm, color=COLOR[e], lw=1.5, zorder=2)
    for _, r in d.iterrows():
        hollow = r.sf > 8
        yerr = None if np.isnan(r.t_lo) else [[r.gm - r.t_lo], [r.t_hi - r.gm]]
        ax.errorbar([r.sf], [r.gm], yerr=yerr, color=COLOR[e], marker=MARK[e], ms=4.6, capsize=2, elinewidth=0.8,
                    mfc=("white" if hollow else COLOR[e]), mew=1.1, zorder=3)
ax.set_xscale("log", base=2); ax.set_yscale("log")
sfs = sorted(CS[CS.engine.isin(A)].sf.unique()); ax.set_xticks(sfs); ax.set_xticklabels([str(int(s)) for s in sfs])
ax.yaxis.set_major_locator(LogLocator(base=10, subs=(1.0, 2.0, 5.0))); ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
ax.yaxis.set_minor_locator(LogLocator(base=10, subs=tuple(range(2, 10)))); ax.yaxis.set_minor_formatter(NullFormatter())
ax.grid(True, which="major", color="#e3e3e3", lw=0.5); ax.grid(True, which="minor", axis="y", color="#f2f2f2", lw=0.4)
ax.axvline(11.3, color="#888888", lw=0.7, ls=":"); ax.text(11.8, ax.get_ylim()[0] * 1.2, "extension\n(hollow, n = 2)", fontsize=5.8, color="#555555")
ax.set_xlabel("TPC-H scale factor (SF)"); ax.set_ylabel("Geo-mean warm latency (s)")
hd = [Line2D([0], [0], color=COLOR[e], marker=MARK[e], lw=1.5, ms=4.5, label=SHORT2[e]) for e in A]
fig.legend(handles=hd, loc="upper center", bbox_to_anchor=(0.55, -0.04), ncol=3, frameon=False)
fig.savefig(f"{FIG}/fig_scaling.pdf"); plt.close(fig)

# ---------- Fig: feasibility matrix ----------
F = pd.read_csv(f"{R}/feasibility.csv")
rows = [("duckdb", "A"), ("polars", "A"), ("polars-stream", "A"), ("spark-local-default", "A"), ("spark-local", "A"),
        ("spark-cluster", "A"), ("polars-tuned", "B"), ("spark-local-tuned", "B")]
lab = {"duckdb": "DuckDB", "polars": "Polars in-memory", "polars-stream": "Polars streaming", "spark-local": "Spark-local",
       "spark-cluster": "Spark co-located", "spark-local-default": "Spark-stock",
       "polars-tuned": "Polars in-mem. + Q9 rewrite", "spark-local-tuned": "Spark-local, disk-frugal"}
cols = [1, 2, 4, 8, 16, 32]
OK, PART, FAIL, NR = "#1E7F4F", "#E69F00", "#A1262B", "#FFFFFF"
fig, ax = plt.subplots(figsize=(W1 + 0.15, 2.75))
for i, (e, ex) in enumerate(rows):
    for j, sf in enumerate(cols):
        d = F[(F.engine == e) & (F.sf == sf)]
        if not len(d):
            ax.add_patch(plt.Rectangle((j, i), 1, 1, fc=NR, ec="#cccccc", lw=0.5))
            ax.text(j + .5, i + .5, "n/r", ha="center", va="center", fontsize=5.5, color="#999999"); continue
        r = d.iloc[0]; frac = r.completed / r.runs
        fc = OK if frac == 1 else (FAIL if frac == 0 else PART)
        ax.add_patch(plt.Rectangle((j + .06, i + .08), .88, .84, fc="white", ec=fc, lw=1.6))
        txt = f"{int(r.completed)}/{int(r.runs)}"
        sub = (f"{r.peak_rss_gb:.1f} GB" if frac == 1 else
               ("disk" if "diskfull" in str(r.failure_mode) else "OOM") + (f" {str(r.failed_query).upper()}" if isinstance(r.failed_query, str) and r.failed_query else ""))
        ax.text(j + .5, i + .38, txt, ha="center", va="center", fontsize=6.3, color="#111111", fontweight="bold")
        ax.text(j + .5, i + .7, sub, ha="center", va="center", fontsize=4.9, color=fc if frac < 1 else "#333333")
ax.set_xlim(0, len(cols)); ax.set_ylim(len(rows), 0)
ax.set_xticks([j + .5 for j in range(len(cols))]); ax.set_xticklabels([f"SF{c}" for c in cols])
ax.set_yticks([i + .5 for i in range(len(rows))]); ax.set_yticklabels([f"{lab[e]} ({ex})" for e, ex in rows], fontsize=6.3)
ax.tick_params(length=0); [s.set_visible(False) for s in ax.spines.values()]
ax.axhline(6, color="#555555", lw=0.6, ls="--")
leg = [Patch(fc="white", ec=OK, lw=1.6, label="all runs complete (peak RSS)"), Patch(fc="white", ec=PART, lw=1.6, label="some runs complete"),
       Patch(fc="white", ec=FAIL, lw=1.6, label="no run completes (mode, query)")]
fig.legend(handles=leg, loc="upper center", bbox_to_anchor=(0.6, -0.01), ncol=2, frameon=False, fontsize=5.8)
fig.savefig(f"{FIG}/fig_feasibility.pdf"); plt.close(fig)
print("figs written")
