"""Produce result tables and colour figures for the paper."""
import json, os, pickle, warnings
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore")
from analysis_lib import *

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "TeX Gyre Termes", "DejaVu Serif"],
                     "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8, "legend.fontsize": 6.8,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.color": "#e3e3e3",
                     "grid.linewidth": 0.5, "axes.edgecolor": "#555555", "lines.linewidth": 1.6,
                     "pdf.fonttype": 42, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
W1 = 3.45  # IEEE single column width (in)

runs = load_runs()
Qdf = query_table(runs); Rdf = run_table(runs)
Qdf.to_csv(f"{RES}/query_obs.csv", index=False); Rdf.to_csv(f"{RES}/run_summary.csv", index=False)
OUTJ = {}
engs = [e for e in ENGINES if e in set(Qdf.engine)]
SFS = sorted(Qdf.sf.unique())

# ---------- status matrix (OOM etc.) ----------
st = Rdf[Rdf["mode"] == "single"].groupby(["engine", "sf"]).agg(
    ok=("status", lambda s: int((s == "ok").sum())), n=("status", "size"),
    failed_at=("failed_at", lambda s: ",".join(sorted(set(str(x) for x in s if isinstance(x, str)))))).reset_index()
st.to_csv(f"{RES}/status.csv", index=False); OUTJ["status"] = st.to_dict("records")
OK = {(r.engine, r.sf) for r in st.itertuples() if r.ok == r.n}

# ---------- warm per-query medians, geomeans, CIs ----------
warm = Qdf[Qdf.phase == "warm"]
med = warm.groupby(["engine", "sf", "q"]).agg(lat=("lat", "median"), cpu_s=("cpu_s", "median"),
        energy_j=("energy_j", "median"), mem_gb=("mem_gb", "median"), util=("util", "median"),
        n=("lat", "size"), cv=("lat", lambda x: x.std() / x.mean())).reset_index()
med.to_csv(f"{RES}/warm_query_medians.csv", index=False)
g = []
for (e, sf), d in med.groupby(["engine", "sf"]):
    if (e, sf) not in OK: continue
    lo, hi = boot_gmean_ci(warm[(warm.engine == e) & (warm.sf == sf)])
    g.append(dict(engine=e, sf=sf, gm_lat=gmean(d.lat), ci_lo=lo, ci_hi=hi, gm_energy=gmean(d.energy_j),
                  sum_lat=d.lat.sum(), sum_energy=d.energy_j.sum(), sum_cost=d.lat.sum() * PRICE_H / 3600,
                  mean_util=d.util.mean(), max_cv=d.cv.max(), median_cv=d.cv.median()))
G = pd.DataFrame(g); G.to_csv(f"{RES}/geomean.csv", index=False); OUTJ["geomean"] = G.to_dict("records")

# ---------- cold / end-to-end ----------
okruns = Rdf[(Rdf["mode"] == "single") & (Rdf.status == "ok")]
E2E = okruns.groupby(["engine", "sf"]).agg(python_start=("python_start_s", "median"), open=("open_s", "median"),
        ttfa=("ttfa_s", "median"), e2e=("e2e_job_s", "median"), e2e_min=("e2e_job_s", "min"),
        e2e_max=("e2e_job_s", "max"), daemon=("daemon_start_s", "median"),
        peak_rss=("peak_rss_gb", "max"), peak_used=("peak_used_gb", "max")).reset_index()
cold = (Qdf[Qdf.phase == "cold"].groupby(["engine", "sf", "rep"]).lat.sum()
        .groupby(["engine", "sf"]).median().rename("cold_sum").reset_index())
E2E = E2E.merge(cold, on=["engine", "sf"], how="left")
E2E.to_csv(f"{RES}/e2e.csv", index=False); OUTJ["e2e"] = E2E.to_dict("records")
peakall = Rdf[Rdf["mode"] == "single"].groupby(["engine", "sf"]).peak_rss_gb.max().reset_index()
peakall.to_csv(f"{RES}/peak_rss_all.csv", index=False)

# ---------- speedups vs spark-local (per query, warm medians) ----------
sp = []
for sf in SFS:
    base = med[(med.engine == "spark-local") & (med.sf == sf)].set_index("q").lat
    for e in engs:
        if (e, sf) not in OK or ("spark-local", sf) not in OK: continue
        d = med[(med.engine == e) & (med.sf == sf)].set_index("q").lat
        r = (base / d).dropna()
        sp.append(dict(engine=e, sf=sf, gm_speedup=gmean(r), min=r.min(), max=r.max(),
                       minq=r.idxmin(), maxq=r.idxmax()))
SP = pd.DataFrame(sp); SP.to_csv(f"{RES}/speedup_vs_spark_local.csv", index=False); OUTJ["speedup"] = SP.to_dict("records")

# ---------- ANOVA on log warm latency ----------
try:
    import statsmodels.formula.api as smf, statsmodels.api as sm
    MAIN = {"duckdb", "polars", "polars-stream", "spark-local", "spark-cluster"}
    A = warm[warm.apply(lambda r: (r.engine, r.sf) in OK and r.sf <= 8 and r.engine in MAIN, axis=1)].copy()  # main design only
    A["loglat"] = np.log(A.lat); A["lsf"] = np.log2(A.sf)
    m = smf.ols("loglat ~ C(engine) * lsf + C(engine) * C(qclass)", data=A).fit()
    av = sm.stats.anova_lm(m, typ=2)
    av["eta2_partial"] = av["sum_sq"] / (av["sum_sq"] + av.loc["Residual", "sum_sq"])
    av.to_csv(f"{RES}/anova.csv"); OUTJ["anova_r2"] = m.rsquared
    # scaling exponent per engine: log lat = a + b*log(sf)
    slopes = []
    for e in engs:
        d = A[A.engine == e]
        if d.sf.nunique() < 2: continue
        mm = smf.ols("np.log(lat) ~ np.log(sf) + C(q)", data=d).fit()
        b = mm.params["np.log(sf)"]; ci = mm.conf_int().loc["np.log(sf)"].tolist()
        slopes.append(dict(engine=e, b=b, ci_lo=ci[0], ci_hi=ci[1], r2=mm.rsquared, n=len(d)))
    SL = pd.DataFrame(slopes); SL.to_csv(f"{RES}/scaling_exponent.csv", index=False); OUTJ["slopes"] = SL.to_dict("records")
except Exception as x:
    print("anova failed", x)

# ---------- concurrency ----------
cr = []
for r in runs:
    if r["mode"] != "conc" or r["status"] != "ok": continue
    ms = next(e["s"] for e in r["events"] if e.get("ev") == "makespan")
    ql = [e["s"] for e in r["events"] if e.get("ev") == "q"]
    errs = [e for e in r["events"] if e.get("ev") == "qerr"]
    cr.append(dict(engine=r["engine"], sf=r["sf"], n=r["arg"], rep=r["rep"], makespan=ms, nq=len(ql),
                   qph=len(ql) / ms * 3600, p50=np.median(ql), p95=np.percentile(ql, 95), errors=len(errs),
                   peak_rss=max(s[3] for s in r["samples"]) / 2**30 if len(r["samples"][0]) > 3 else np.nan))
CR = pd.DataFrame(cr)
cst = pd.DataFrame([dict(engine=r["engine"], sf=r["sf"], n=r["arg"], rep=r["rep"], status=r["status"])
                    for r in runs if r["mode"] == "conc"])
cst.to_csv(f"{RES}/conc_status.csv", index=False)
if len(CR):
    CS = CR.groupby(["engine", "sf", "n"]).agg(qph=("qph", "mean"), qph_sd=("qph", "std"), p50=("p50", "mean"),
                                                p95=("p95", "mean"), makespan=("makespan", "mean"),
                                                peak_rss=("peak_rss", "max"), errors=("errors", "sum"), reps=("rep", "size")).reset_index()
    CS.to_csv(f"{RES}/concurrency.csv", index=False); OUTJ["conc"] = CS.to_dict("records")

# ---------- correctness vs DuckDB ----------
def relerr(a, b):
    if len(a) != len(b): return ("rowcount", np.inf)
    worst = 0.0
    for ra, rb in zip(a, b):
        if len(ra) != len(rb): return ("arity", np.inf)
        for x, y in zip(ra, rb):
            try:
                fx, fy = float(x), float(y)
                if isinstance(x, (str,)) : raise ValueError
                d = abs(fx - fy) / max(abs(fy), 1e-9); worst = max(worst, d)
            except (TypeError, ValueError):
                if str(x) != str(y): return ("value", np.inf)
    return ("ok", worst)
cor = []
for f in sorted(glob.glob(f"{RES}/answers/*.pkl")):
    name = os.path.basename(f)[:-4]; eng, sfs, tag = name.rsplit("_", 2); sf = int(sfs[2:])
    ref = f"{RES}/answers/duckdb_sf{sf}_{tag}.pkl"
    if eng == "duckdb" or not os.path.exists(ref): continue
    A_, B_ = pickle.load(open(f, "rb")), pickle.load(open(ref, "rb"))
    for q in ORDER:
        if q in A_ and q in B_:
            kind, w = relerr(A_[q], B_[q]); cor.append(dict(engine=eng, sf=sf, tag=tag, q=q, kind=kind, max_rel_err=w))
COR = pd.DataFrame(cor)
if len(COR):
    COR.to_csv(f"{RES}/correctness_raw.csv", index=False)
    CORS = COR.groupby(["engine", "q"]).agg(kinds=("kind", lambda s: ",".join(sorted(set(s)))),
                                             max_rel_err=("max_rel_err", "max"), n=("kind", "size")).reset_index()
    CORS.to_csv(f"{RES}/correctness.csv", index=False); OUTJ["correctness"] = CORS.to_dict("records")

# ---------- energy sensitivity across CCF coefficient sets ----------
sens = []
W = warm.copy(); W["cpu_c"] = np.minimum(W.cpu_s, VCPU * W.lat)
for name, (pmin, pmax, pue) in CCF_SETS.items():
    W["e"] = [energy_set(t, c_, m, pmin, pmax, pue) for t, c_, m in zip(W.lat, W.cpu_c, W.mem_gb)]
    pm = W.groupby(["engine", "sf", "q"]).e.median().groupby(["engine", "sf"]).sum()
    for sf in SFS:
        if ("spark-local", sf) in pm.index and ("duckdb", sf) in pm.index:
            sens.append(dict(provider=name, sf=sf, duck_j=pm[("duckdb", sf)], spark_j=pm[("spark-local", sf)],
                             ratio=pm[("spark-local", sf)] / pm[("duckdb", sf)]))
SENS = pd.DataFrame(sens); SENS.to_csv(f"{RES}/energy_sensitivity.csv", index=False); OUTJ["energy_sens"] = SENS.to_dict("records")
json.dump(OUTJ, open(f"{RES}/summary.json", "w"), indent=1, default=float)

# =================== FIGURES ===================
# Revision 2: main figures show Experiment A (default / documented-baseline configurations) only;
# Experiment B and feasibility outcomes are reported in their own table and figure (figs_rev2.py).
engs = [e for e in engs if e in ("duckdb", "polars", "polars-stream", "spark-local", "spark-cluster")]
def nice_log(ax, axis="y"):
    """Log axis with labelled 1-2-5 ticks and light minor grid, so values can be read off directly."""
    from matplotlib.ticker import LogLocator, FuncFormatter, NullFormatter
    fmt = FuncFormatter(lambda v, _: (f"{v:g}" if v >= 0.01 else f"{v:.0e}"))
    loc = LogLocator(base=10, subs=(1.0, 2.0, 5.0))
    tgt = ax.yaxis if axis == "y" else ax.xaxis
    tgt.set_major_locator(loc); tgt.set_major_formatter(fmt)
    tgt.set_minor_locator(LogLocator(base=10, subs=tuple(range(2, 10)))); tgt.set_minor_formatter(NullFormatter())
    ax.grid(True, which="minor", axis=axis, color="#f0f0f0", linewidth=0.4)


def legend_handles(es):
    return [Line2D([0], [0], color=COLOR[e], marker=MARK[e], lw=1.6, ms=4.5, label=SHORT[e]) for e in es]

# Fig 2: geomean warm latency vs SF (log-log) with bootstrap CI; failed cells shown in a strip above the data
from matplotlib.lines import Line2D as _L2
fig, ax = plt.subplots(figsize=(W1, 2.9))
fails = []
for e in engs:
    d = G[G.engine == e].sort_values("sf")
    if len(d):
        ax.errorbar(d.sf, d.gm_lat, yerr=[d.gm_lat - d.ci_lo, d.ci_hi - d.gm_lat], color=COLOR[e], marker=MARK[e],
                    ms=4.5, capsize=2, lw=1.6, elinewidth=0.8, mfc=("white" if e == "spark-local-tuned" else COLOR[e]))
    for sf in SFS:
        if (e, sf) not in OK and len(st[(st.engine == e) & (st.sf == sf)]):
            fails.append((e, sf))
ax.set_xscale("log", base=2); ax.set_yscale("log"); ax.set_xticks(SFS); ax.set_xticklabels([str(s) for s in SFS])
ymin = G.ci_lo.min() * 0.7; ymax = G.ci_hi.max() * 1.6; strip = ymax * 2.2
order = [e for e in engs]
for sf in SFS:
    fe = [e for (e, s) in fails if s == sf]
    for k, e in enumerate(fe):
        x = sf * 2 ** ((k - (len(fe) - 1) / 2) * 0.13)
        ax.scatter([x], [strip], marker="x", color=COLOR[e], s=26, linewidths=1.4, zorder=5, clip_on=False)
ax.set_ylim(ymin, strip * 1.8)
ax.axhline(ymax * 1.35, color="#bbbbbb", lw=0.6)
ax.text(1.0, strip * 1.25, "failed runs (×, colour = engine)", fontsize=6, color="#444444", va="bottom")
nice_log(ax, "y")
_t = [t for t in ax.get_yticks() if ymin <= t <= ymax * 1.3]; ax.set_yticks(_t); ax.set_yticklabels([f"{t:g}" for t in _t])
ax.set_ylim(ymin, strip * 1.8)
if max(SFS) > 8:
    ax.axvline(11.3, color="#777777", lw=0.7, ls=":")
    ax.text(11.8, ymin * 1.15, "extension", fontsize=6, color="#555555")
ax.set_xlabel("TPC-H scale factor (SF)"); ax.set_ylabel("Geo-mean warm latency (s)")
fig.legend(handles=legend_handles(engs), loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(0.55, 0.02), fontsize=6.3)
fig.savefig(f"{FIG}/fig_scaling.pdf"); plt.close(fig)

# Fig 3: per-query warm speedup over Spark-local at largest SF where all ok (heat table as dot plot)
_cmp_engs = [e for e in engs if e in ("duckdb", "polars", "polars-stream", "polars-tuned", "spark-local", "spark-cluster")]
sf_cmp = max([sf for sf in SFS if all((e, sf) in OK for e in _cmp_engs)], default=None)
if sf_cmp:
    fig, ax = plt.subplots(figsize=(W1, 2.2))
    es = [e for e in _cmp_engs if e != "spark-local" and (e, sf_cmp) in OK]
    base = med[(med.engine == "spark-local") & (med.sf == sf_cmp)].set_index("q").lat
    x = np.arange(len(ORDER)); wbar = 0.8 / len(es)
    for i, e in enumerate(es):
        d = med[(med.engine == e) & (med.sf == sf_cmp)].set_index("q").lat
        vals = [base[q] / d[q] for q in ORDER]
        ax.bar(x + (i - (len(es) - 1) / 2) * wbar, vals, width=wbar * 0.9, color=COLOR[e], label=SHORT[e],
               edgecolor="white", linewidth=0.4)
    ax.axhline(1, color="#333333", lw=0.8, ls="--"); ax.set_yscale("log"); nice_log(ax, "y")
    ax.set_xticks(x); ax.set_xticklabels([q.upper() for q in ORDER])
    ax.set_ylabel(f"Speed-up vs Spark-local (×), SF{sf_cmp}")
    ax.legend(loc="upper right", ncol=2, frameon=False); ax.grid(axis="x", visible=False)
    fig.savefig(f"{FIG}/fig_speedup.pdf"); plt.close(fig); OUTJ["sf_cmp"] = int(sf_cmp)

# Fig 4: end-to-end one-off job decomposition (stacked) at SF1 and SF8/largest
fig, axes = plt.subplots(1, 2, figsize=(W1 + 0.25, 2.2), sharey=False)
for ax, sf in zip(axes, [SFS[0], max(s for s in SFS if ("spark-local", s) in OK)]):
    d = E2E[E2E.sf == sf].set_index("engine")
    es = [e for e in engs if e in d.index]
    parts = [("daemon", "Cluster daemons", "#555555"), ("python_start", "Interpreter start", "#B3B3B3"),
             ("open", "Session + catalog", "#F0E442"), ("cold_sum", "8 cold queries", "#0072B2")]
    bottom = np.zeros(len(es))
    for col, lab, colr in parts:
        v = np.nan_to_num(np.array([d.loc[e, col] if col in d.columns else 0 for e in es], float))
        ax.bar(range(len(es)), v, bottom=bottom, color=colr, label=lab, width=0.65, edgecolor="white", linewidth=0.5)
        bottom += v
    for i, b in enumerate(bottom): ax.text(i, b, f"{b:.0f}", ha="center", va="bottom", fontsize=6.5)
    ax.set_xticks(range(len(es))); ax.set_xticklabels([SHORT[e] for e in es], fontsize=6.2, rotation=35, ha="right")
    ax.set_title(f"SF{sf}"); ax.grid(axis="x", visible=False); ax.set_ylim(0, bottom.max() * 1.15)
axes[0].set_ylabel("Seconds to last answer")
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.08), fontsize=6.2)
fig.savefig(f"{FIG}/fig_e2e.pdf"); plt.close(fig)

# Fig 5: peak RSS vs SF with memory limit
fig, ax = plt.subplots(figsize=(W1, 2.1))
for e in engs:
    d = peakall[peakall.engine == e].sort_values("sf")
    ax.plot(d.sf, d.peak_rss_gb, color=COLOR[e], marker=MARK[e], ms=4.5, label=SHORT[e])
ax.axhline(6.0, color="#B00020", lw=1, ls="--"); ax.text(SFS[0], 6.1, "≈6 GB cgroup limit (OOM-kill)", fontsize=6.5, color="#B00020")
ax.set_xscale("log", base=2); ax.set_xticks(SFS); ax.set_xticklabels([str(s) for s in SFS])
ax.set_xlabel("TPC-H scale factor (SF)"); ax.set_ylabel("Peak resident memory (GB)"); ax.set_ylim(0, 7)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=3, frameon=False, fontsize=6.3)
fig.savefig(f"{FIG}/fig_memory.pdf"); plt.close(fig)

# Fig 6: concurrency throughput
if len(CR):
    sfc = sorted(CS.sf.unique())
    fig, axes = plt.subplots(1, len(sfc), figsize=(W1 + 0.25, 2.1))
    axes = np.atleast_1d(axes)
    for ax, sf in zip(axes, sfc):
        for e in engs:
            d = CS[(CS.engine == e) & (CS.sf == sf)].sort_values("n")
            if len(d): ax.errorbar(d.n, d.qph, yerr=d.qph_sd.fillna(0), color=COLOR[e], marker=MARK[e], ms=4, capsize=2, lw=1.4, elinewidth=0.7)
        ax.set_xticks([1, 2, 4]); ax.set_xlabel("Concurrent query streams"); ax.set_title(f"SF{sf}"); ax.set_yscale("log"); nice_log(ax, "y")
    axes[0].set_ylabel("Throughput (queries / hour)")
    fig.legend(handles=legend_handles(engs), loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(0.5, 1.12), fontsize=6.3)
    fig.tight_layout(); fig.savefig(f"{FIG}/fig_concurrency.pdf"); plt.close(fig)

# Fig 7: Pareto - energy per 8-query pass vs latency, all SF
fig, ax = plt.subplots(figsize=(W1, 2.4))
for e in engs:
    d = G[G.engine == e].sort_values("sf")
    ax.plot(d.sum_lat, d.sum_energy, color=COLOR[e], marker=MARK[e], ms=4.5, lw=0.9, label=SHORT[e])
    for _, r in d.iterrows():
        if e not in ("duckdb", "spark-local"): continue
        ax.annotate(f"SF{int(r.sf)}", (r.sum_lat, r.sum_energy), textcoords="offset points", xytext=(3, -7), fontsize=5.6, color="#444444")
ax.set_xscale("log"); ax.set_yscale("log"); nice_log(ax, "y"); nice_log(ax, "x")
ax.set_xlabel("Warm latency, 8-query pass (s)"); ax.set_ylabel("Model-est. energy per pass (J)")
ax.legend(loc="upper left", frameon=False, fontsize=6.3)
fig.savefig(f"{FIG}/fig_pareto.pdf"); plt.close(fig)

json.dump(OUTJ, open(f"{RES}/summary.json", "w"), indent=1, default=float)
print("done", len(Qdf), "query obs;", len(Rdf), "runs")
