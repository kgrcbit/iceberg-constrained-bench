"""A/B test of the access path on one engine (DuckDB): Iceberg metadata scan vs. reading the same
snapshot's Parquet files directly (the path Spark used). Warm, 3 passes x 3 fresh processes per mode."""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import sys, json, time, subprocess, os
sys.path.insert(0, f"{LH}")
def child(mode, sf):
    import duckdb
    from duckdb_extensions import import_extension
    from engines import catalog
    from queries import TABLES, Q, ORDER
    import_extension("iceberg"); con = duckdb.connect(); con.load_extension("iceberg"); con.execute("SET threads=2")
    cat = catalog()
    for t in TABLES:
        tbl = cat.load_table(f"sf{sf}.{t}")
        if mode == "iceberg":
            con.execute(f"CREATE VIEW {t} AS SELECT * FROM iceberg_scan('{tbl.metadata_location.replace('file://','')}')")
        else:
            files = [f.file.file_path.replace("file://", "") for f in tbl.scan().plan_files()]
            con.execute(f"CREATE VIEW {t} AS SELECT * FROM read_parquet({files!r})")
    for q in ORDER: con.execute(Q[q]).fetchall()
    res = []
    for p in range(3):
        for q in ORDER:
            t = time.time(); con.execute(Q[q]).fetchall(); res.append((q, time.time() - t))
    print(json.dumps(res))
if __name__ == "__main__":
    if sys.argv[1] == "run":
        out = []
        for sf in [4, 8]:
            for rep in range(3):
                for mode in ["iceberg", "parquet"]:
                    os.sync(); open("/proc/sys/vm/drop_caches", "w").write("3"); time.sleep(1)
                    r = subprocess.run([sys.executable, __file__, mode, str(sf)], capture_output=True, text=True)
                    for q, s in json.loads(r.stdout.strip().splitlines()[-1]): out.append(dict(sf=sf, rep=rep, mode=mode, q=q, s=s))
                    print(sf, rep, mode, round(sum(x['s'] for x in out if x['sf']==sf and x['rep']==rep and x['mode']==mode)/3, 2), flush=True)
        json.dump(out, open(f"{LH}/results/access_ab.json", "w"))
    else:
        child(sys.argv[1], int(sys.argv[2]))
