"""Load TPC-H Parquet (tpchgen-rs) into Apache Iceberg tables via PyIceberg.

Catalog: PyIceberg SqlCatalog (SQLite) with a local-filesystem warehouse.
One namespace per scale factor (sf1, sf2, sf4, sf8). Large tables are appended
in batches of ~4M rows so that each append writes bounded-size data files.
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import os, sys, time, json
import pyarrow as pa, pyarrow.parquet as pq
from pyiceberg.catalog.sql import SqlCatalog

ROOT = f"{LH}"
WH = f"{ROOT}/warehouse"
os.makedirs(WH, exist_ok=True)
cat = SqlCatalog("lh", uri=f"sqlite:///{ROOT}/catalog.db", warehouse=f"file://{WH}")
TABLES = ["region", "nation", "supplier", "customer", "part", "partsupp", "orders", "lineitem"]
BATCH = 4_000_000

def load(sf):
    ns = f"sf{sf}"
    if ns not in [n[0] for n in cat.list_namespaces()]:
        cat.create_namespace(ns)
    log = {}
    for t in TABLES:
        ident = f"{ns}.{t}"
        if cat.table_exists(ident):
            cat.drop_table(ident)
        pf = pq.ParquetFile(f"{ROOT}/raw/sf{sf}/{t}.parquet")
        schema = pf.schema_arrow
        tbl = cat.create_table(ident, schema=schema,
                               properties={"write.parquet.compression-codec": "zstd",
                                           "write.target-file-size-bytes": str(256 * 1024 * 1024)})
        t0 = time.time(); rows = 0; buf = []; nbuf = 0
        for b in pf.iter_batches(batch_size=500_000):
            buf.append(b); nbuf += b.num_rows
            if nbuf >= BATCH:
                tbl.append(pa.Table.from_batches(buf, schema=schema)); rows += nbuf; buf = []; nbuf = 0
        if buf:
            tbl.append(pa.Table.from_batches(buf, schema=schema)); rows += nbuf
        log[t] = {"rows": rows, "load_s": round(time.time() - t0, 2),
                  "snapshots": len(tbl.refresh().snapshots()),
                  "metadata": tbl.metadata_location}
        print(sf, t, log[t], flush=True)
    return log

if __name__ == "__main__":
    out = {}
    for sf in [int(x) for x in sys.argv[1:]]:
        out[f"sf{sf}"] = load(sf)
    with open(f"{ROOT}/load_log_{'_'.join(sys.argv[1:])}.json", "w") as f:
        json.dump(out, f, indent=1)
