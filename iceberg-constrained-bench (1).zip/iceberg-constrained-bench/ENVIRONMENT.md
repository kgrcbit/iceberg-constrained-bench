# Execution environment

| Item | Value |
|---|---|
| OS | Ubuntu 24.04.5 LTS |
| Kernel | 6.18.44-fc-v64 |
| Virtualization | Firecracker micro-VM (KVM); no RAPL/MSR/hwmon |
| CPU model | Intel(R) Xeon(R) Processor @ 2.80GHz |
| vCPUs | 2 |
| RAM | 7.8 GiB (8031 MiB) |
| cgroup memory limit | cgroup v1 memory.limit_in_bytes = 6273757184 bytes (5.84 GiB) on the benchmark process group's cgroup; exceeding it triggers the kernel OOM killer |
| Disk / filesystem | /dev/vda ext4   rw,relatime,discard,resv_strict,resuid=65534,resgid=65534 |
| Python | 3.13.15 |
| DuckDB | 1.5.5 (git d8cdaa33fd); extensions iceberg 45163a28, avro f9d5902, tpch v1.5.5 |
| Polars | 1.44.2 (PyPI wheel; build commit not exposed by the wheel) |
| PyArrow | 25.0.1 |
| PyIceberg | 0.12.0 |
| Apache Spark | 4.2.0 (PyPI source distribution, bundled jars) |
| Java | openjdk version "21.0.12.1" 2026-08-18 |
| JVM flags (driver) | -Xmx4g (local), -Xmx1g driver / 1400m executors (co-located standalone); Spark default JVM options otherwise |
| Spark-local (Exp. A) | local[2]; spark.driver.memory=4g; spark.sql.shuffle.partitions=4; spark.sql.adaptive.enabled=true; spark.scheduler.mode=FAIR; spark.ui.enabled=false |
| Spark-stock (Exp. A) | local[2]; spark.driver.memory=4g; all other settings at Spark 4.2.0 defaults (200 shuffle partitions, AQE on, FIFO) |
| Spark disk-frugal (Exp. B) | Spark-local settings plus spark.io.compression.codec=zstd, spark.cleaner.referenceTracking.blocking=true, spark.cleaner.periodicGC.interval=1min, explicit JVM GC after each query |
| Spark co-located standalone (Exp. A) | master + 2 workers (1 core, 1500m each) on the same VM; executors 1400m, driver 1g, spark.cores.max=2 |
| Environment variables | SPARK_HOME=<Spark 4.2.0 jars>; SPARK_LOCAL_IP=127.0.0.1; PYSPARK_PYTHON=python3; PYTHONWARNINGS=ignore |
| Container image | none (bare VM); package installation commands listed below |
| Data generation | tpchgen-cli -s {SF} --format parquet (SF1-8); SF16/32 part-wise via load_large.py (--parts/--part); deterministic, no random seed |
| Iceberg loading | PyIceberg SqlCatalog (SQLite), appends of ~4M rows, Parquet zstd, write.target-file-size-bytes=268435456 |
| Random seeds | bootstrap: numpy default_rng(7) (rev 1) and default_rng(20261003) (rev 2); workloads are deterministic |

## Package installation
```
pip install duckdb==1.5.5 duckdb_extension_iceberg==1.5.5 duckdb_extension_avro duckdb_extension_tpch polars==1.44.2 'pyiceberg[sql-sqlite,pyarrow]'==0.12.0 tpchgen-cli psutil statsmodels scipy pandas matplotlib
pip download --no-binary :all: pyspark==4.2.0  # jars taken from deps/
```

## Query texts (SQL engines)

### Q1
```sql
select l_returnflag, l_linestatus,
  sum(l_quantity) as sum_qty, sum(l_extendedprice) as sum_base_price,
  sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
  sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
  avg(l_quantity) as avg_qty, avg(l_extendedprice) as avg_price,
  avg(l_discount) as avg_disc, count(*) as count_order
from lineitem
where l_shipdate <= date '1998-09-02'
group by l_returnflag, l_linestatus
order by l_returnflag, l_linestatus
```

### Q3
```sql
select l_orderkey, sum(l_extendedprice * (1 - l_discount)) as revenue,
  o_orderdate, o_shippriority
from customer, orders, lineitem
where c_mktsegment = 'BUILDING' and c_custkey = o_custkey and l_orderkey = o_orderkey
  and o_orderdate < date '1995-03-15' and l_shipdate > date '1995-03-15'
group by l_orderkey, o_orderdate, o_shippriority
order by revenue desc, o_orderdate, l_orderkey
limit 10
```

### Q5
```sql
select n_name, sum(l_extendedprice * (1 - l_discount)) as revenue
from customer, orders, lineitem, supplier, nation, region
where c_custkey = o_custkey and l_orderkey = o_orderkey and l_suppkey = s_suppkey
  and c_nationkey = s_nationkey and s_nationkey = n_nationkey
  and n_regionkey = r_regionkey and r_name = 'ASIA'
  and o_orderdate >= date '1994-01-01' and o_orderdate < date '1995-01-01'
group by n_name
order by revenue desc
```

### Q6
```sql
select sum(l_extendedprice * l_discount) as revenue
from lineitem
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1995-01-01'
  and l_discount between 0.05 and 0.07 and l_quantity < 24
```

### Q9
```sql
select nation, o_year, sum(amount) as sum_profit
from (
  select n_name as nation, extract(year from o_orderdate) as o_year,
    l_extendedprice * (1 - l_discount) - ps_supplycost * l_quantity as amount
  from part, supplier, lineitem, partsupp, orders, nation
  where s_suppkey = l_suppkey and ps_suppkey = l_suppkey and ps_partkey = l_partkey
    and p_partkey = l_partkey and o_orderkey = l_orderkey and s_nationkey = n_nationkey
    and p_name like '%green%'
) as profit
group by nation, o_year
order by nation, o_year desc
```

### Q10
```sql
select c_custkey, c_name, sum(l_extendedprice * (1 - l_discount)) as revenue,
  c_acctbal, n_name, c_address, c_phone, c_comment
from customer, orders, lineitem, nation
where c_custkey = o_custkey and l_orderkey = o_orderkey
  and o_orderdate >= date '1993-10-01' and o_orderdate < date '1994-01-01'
  and l_returnflag = 'R' and c_nationkey = n_nationkey
group by c_custkey, c_name, c_acctbal, c_phone, n_name, c_address, c_comment
order by revenue desc, c_custkey
limit 20
```

### Q13
```sql
select c_count, count(*) as custdist
from (
  select c_custkey, count(o_orderkey) as c_count
  from customer left outer join orders
    on c_custkey = o_custkey and o_comment not like '%special%requests%'
  group by c_custkey
) as c_orders
group by c_count
order by custdist desc, c_count desc
```

### Q18
```sql
select c_name, c_custkey, o_orderkey, o_orderdate, o_totalprice, sum(l_quantity) as sum_qty
from customer, orders, lineitem
where o_orderkey in (
    select l_orderkey from lineitem group by l_orderkey having sum(l_quantity) > 300)
  and c_custkey = o_custkey and o_orderkey = l_orderkey
group by c_name, c_custkey, o_orderkey, o_orderdate, o_totalprice
order by o_totalprice desc, o_orderdate, o_orderkey
limit 100
```

Polars native LazyFrame plans: see polars_native.py (NATIVE; TUNED replaces Q9 with q9_semi).

## Iceberg metadata
Current metadata.json paths per table are recorded in load_log_*.json; the warehouse directory layout is warehouse/sf{SF}/{table}/{metadata,data}.
