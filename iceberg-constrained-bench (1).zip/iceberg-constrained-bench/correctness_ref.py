"""Correctness against references independent of the engine under test (SF1).

Reference 1: TPC-H answer set for SF1 (qualification parameters) as distributed with DuckDB's TPC-H extension
             (tpch_answers()). Our queries use the qualification parameters and tpchgen-rs reproduces dbgen data.
Reference 2: exact decimal recomputation with Apache Arrow compute (decimal128 arithmetic, no float), reading
             the same Iceberg snapshot's Parquet files, for the expressions where engines diverged (Q1, Q3, Q6).
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import sys, json, pickle, io, csv
from decimal import Decimal, ROUND_HALF_UP
sys.path.insert(0, f"{LH}")
import pyarrow as pa, pyarrow.compute as pc, pyarrow.parquet as pq
import duckdb
from duckdb_extensions import import_extension
from engines import catalog
R = f"{LH}/results"

def files(t):
    return [f.file.file_path.replace("file://", "") for f in catalog().load_table(f"sf1.{t}").scan().plan_files()]
def table(t, cols):
    return pa.concat_tables([pq.read_table(f, columns=cols) for f in files(t)])

# ---- reference 2: exact Arrow decimal arithmetic ----
li = table("lineitem", ["l_orderkey", "l_quantity", "l_extendedprice", "l_discount", "l_tax", "l_returnflag", "l_linestatus", "l_shipdate"])
one = pa.scalar(Decimal("1.00"), pa.decimal128(15, 2))
D = lambda a, p, s: pc.cast(a, pa.decimal128(p, s))
disc_price = D(pc.multiply(D(li["l_extendedprice"], 15, 2), D(pc.subtract(one, li["l_discount"]), 15, 2)), 20, 4)   # scale 4, exact

charge = pc.multiply(disc_price, D(pc.add(one, li["l_tax"]), 15, 2))                                    # scale 6, exact
import datetime as dt
m1 = pc.less_equal(li["l_shipdate"], pa.scalar(dt.date(1998, 9, 2)))
m_af = pc.and_(m1, pc.and_(pc.equal(li["l_returnflag"], "A"), pc.equal(li["l_linestatus"], "F")))
ref = {}
ref["q1_sum_disc_price_AF"] = pc.sum(pc.filter(disc_price, m_af)).as_py()
ref["q1_sum_charge_AF"] = pc.sum(pc.filter(charge, m_af)).as_py()
ref["q1_avg_disc_AF"] = pc.sum(pc.filter(li["l_discount"], m_af)).as_py() / Decimal(pc.sum(pc.cast(m_af, pa.int64())).as_py())
m6 = pc.and_(pc.and_(pc.greater_equal(li["l_shipdate"], pa.scalar(dt.date(1994, 1, 1))), pc.less(li["l_shipdate"], pa.scalar(dt.date(1995, 1, 1)))),
             pc.and_(pc.and_(pc.greater_equal(li["l_discount"], pa.scalar(Decimal("0.05"), pa.decimal128(15, 2))),
                             pc.less_equal(li["l_discount"], pa.scalar(Decimal("0.07"), pa.decimal128(15, 2)))),
                     pc.less(li["l_quantity"], pa.scalar(Decimal("24"), pa.decimal128(15, 2)))))
ref["q6_revenue"] = pc.sum(pc.filter(pc.multiply(li["l_extendedprice"], li["l_discount"]), m6)).as_py()
# Q3 revenue of the top order (2456423): sum over its lineitems shipped after 1995-03-15
m3 = pc.and_(pc.equal(li["l_orderkey"], 2456423), pc.greater(li["l_shipdate"], pa.scalar(dt.date(1995, 3, 15))))
ref["q3_revenue_2456423"] = pc.sum(pc.filter(disc_price, m3)).as_py()

# ---- reference 1: TPC-H SF1 answers ----
import_extension("tpch"); con = duckdb.connect(); con.load_extension("tpch")
ans = {q: con.sql(f"select answer from tpch_answers() where scale_factor=1 and query_nr={q}").fetchone()[0] for q in (1, 3, 5, 6, 9, 10, 13, 18)}
def parse(txt):
    rows = list(csv.reader(io.StringIO(txt), delimiter="|"))
    return rows[0], rows[1:]

# ---- engine answers (first repetition, SF1) ----
eng = {e: pickle.load(open(f"{R}/answers/{e}_sf1_r1.pkl", "rb")) for e in ["duckdb", "polars", "polars-stream", "spark-local"]}

TEXT_COLS = {"c_address", "c_comment"}          # generator text differs from dbgen; not an engine property
def cmpval(a, b, col):
    """Returns (strict_ok, tpch_ok, absdiff). strict: equal after rounding to the reference's decimals.
    tpch: TPC-H clause 2.1.3.5 style: money/ratios equal after rounding to 0.01; averages within 1% after rounding."""
    try:
        bd = Decimal(b.strip()); ad = Decimal(str(a))
    except Exception:
        ok = str(a).strip() == b.strip(); return ok, ok, 0.0
    dec = -bd.as_tuple().exponent if bd.as_tuple().exponent < 0 else 0
    q = Decimal(1).scaleb(-dec)
    strict = ad.quantize(q, rounding=ROUND_HALF_UP) == bd.quantize(q, rounding=ROUND_HALF_UP)
    c = Decimal("0.01"); ar, br = ad.quantize(c, rounding=ROUND_HALF_UP), bd.quantize(c, rounding=ROUND_HALF_UP)
    if col.startswith("avg"): tp = abs(ar - br) <= abs(br) * Decimal("0.01")
    else: tp = ar == br
    return strict, tp, float(abs(ad - bd))

summary = []
for qn in (1, 3, 5, 6, 9, 10, 13, 18):
    hdr, rows = parse(ans[qn]); qk = f"q{qn}"
    for e, A in eng.items():
        got = A[qk]
        if len(got) != len(rows):
            summary.append(dict(q=qk, engine=e, rows_ok=False)); continue
        cells = ns = nt = 0; maxdiff = 0.0
        for gr, rr in zip(got, rows):
            for col, gv, rv in zip(hdr, gr, rr):
                if col in TEXT_COLS: continue
                s_ok, t_ok, d = cmpval(gv, rv, col); cells += 1; ns += (not s_ok); nt += (not t_ok); maxdiff = max(maxdiff, d)
        summary.append(dict(q=qk, engine=e, rows_ok=True, cells=cells, strict_mismatch=ns, tpch_mismatch=nt, max_abs_diff=maxdiff,
                            comparable=(qn != 13)))
# cross-engine agreement for Q13 (its predicate depends on generated comment text)
q13 = {e: [tuple(map(str, r)) for r in A["q13"]] for e, A in eng.items()}
cross13 = all(v == q13["duckdb"] for v in q13.values())

# expression-level table for divergent expressions
def eng_val(e, q, row, col):
    return eng[e][q][row][col]
q1_af_row = 0
expr = [
  ("Q1", "sum(l_extendedprice*(1-l_discount)), A/F", ref["q1_sum_disc_price_AF"], {e: eng_val(e, "q1", 0, 4) for e in eng}, "exact decimal product, scale 4"),
  ("Q1", "sum(...*(1+l_tax)), A/F", ref["q1_sum_charge_AF"], {e: eng_val(e, "q1", 0, 5) for e in eng}, "exact decimal product, scale 6"),
  ("Q1", "avg(l_discount), A/F", ref["q1_avg_disc_AF"], {e: eng_val(e, "q1", 0, 8) for e in eng}, "decimal average"),
  ("Q3", "revenue, order 2456423", ref["q3_revenue_2456423"], {e: eng_val(e, "q3", 0, 1) for e in eng}, "exact decimal product, scale 4"),
  ("Q6", "sum(l_extendedprice*l_discount)", ref["q6_revenue"], {e: eng_val(e, "q6", 0, 0) for e in eng}, "exact decimal product, scale 4"),
]
tab = []
for q, ex, rv, vals, sem in expr:
    row = dict(query=q, expression=ex, reference=str(rv), semantics=sem)
    for e, v in vals.items():
        row[e] = str(v); row[e + "_absdiff"] = float(abs(Decimal(str(v)) - Decimal(str(rv))))
    tab.append(row)
json.dump(dict(q13_cross_engine_identical=cross13, reference_values={k: str(v) for k, v in ref.items()}, tpch_answer_check=summary, expressions=tab),
          open(f"{R}/rev2/correctness_reference.json", "w"), indent=1, default=str)
for s in summary: print(s)
for t in tab: print(t)
