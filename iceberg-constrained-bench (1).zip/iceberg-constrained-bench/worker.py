"""Benchmark worker: runs inside a fresh process, prints JSON event lines to stdout.

usage: worker.py ENGINE SF MODE [args]
  MODE single  : open session, run each query once (cold), then WARM passes of all
                 queries (rotating order). Saves first-run results for validation.
  MODE conc N  : open session, warm-up one pass, then N concurrent streams, each
                 running all 8 queries in a rotated order; reports per-query latency.
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import sys, os, json, time, pickle, threading, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, f"{LH}")
from engines import make
from queries import ORDER

def emit(**kw):
    kw["t"] = time.time()
    sys.stdout.write(json.dumps(kw, default=str) + "\n"); sys.stdout.flush()

def main():
    eng_name, sf, mode = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    tag = sys.argv[5] if len(sys.argv) > 5 else ""
    emit(ev="proc_start")
    eng = make(eng_name)
    t0 = time.time(); eng.open(sf); emit(ev="ready", open_s=time.time() - t0)
    if mode == "single":
        warm = int(sys.argv[4])
        res = {}
        for q in ORDER:                      # cold pass (first execution in this process)
            t = time.time(); r = eng.run(q); d = time.time() - t
            res[q] = r; emit(ev="q", q=q, phase="cold", rep=0, s=d, rows=len(r), ts=t)
        os.makedirs(f"{LH}/results/answers", exist_ok=True)
        with open(f"{LH}/results/answers/{eng_name}_sf{sf}_{tag}.pkl", "wb") as f:
            pickle.dump(res, f)
        for rep in range(1, warm + 1):
            k = (rep - 1) % len(ORDER); order = ORDER[k:] + ORDER[:k]
            for q in order:
                t = time.time(); r = eng.run(q); d = time.time() - t
                emit(ev="q", q=q, phase="warm", rep=rep, s=d, rows=len(r), ts=t)
    else:  # concurrency
        n = int(sys.argv[4])
        for q in ORDER: eng.run(q)          # warm-up pass
        emit(ev="warmup_done")
        def stream(i):
            k = (i * 3) % len(ORDER); order = ORDER[k:] + ORDER[:k]
            for q in order:
                t = time.time()
                try:
                    r = eng.run(q); emit(ev="q", q=q, phase="conc", stream=i, s=time.time() - t, rows=len(r), ts=t)
                except Exception as x:
                    emit(ev="qerr", q=q, stream=i, err=str(x)[:300])
        ths = [threading.Thread(target=stream, args=(i,)) for i in range(n)]
        t = time.time(); [h.start() for h in ths]; [h.join() for h in ths]
        emit(ev="makespan", n=n, s=time.time() - t)
    eng.close(); emit(ev="done")

if __name__ == "__main__":
    main()
