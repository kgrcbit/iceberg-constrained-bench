"""Revision-2 statistical analysis (addresses pseudoreplication, failure-as-outcome, contrasts, diagnostics).

Independent experimental unit = one fresh process (repetition) of an (engine, SF) cell.
Warm passes inside a process are repeated measurements and are first reduced to a per-query median.

Outputs (results/rev2/*):
  run_query.csv        per (config, SF, rep, query): median warm latency  -> analysis unit for the mixed model
  run_level.csv        per (config, SF, rep): geometric mean over the 8 queries
  cell_summary.csv     per (config, SF): run-level geometric mean, t-based 95% CI (df = n_runs - 1), two-stage bootstrap CI
  mixed_main.json      mixed model (Experiment A, SF1-8): fixed effects, LRTs, variance components, diagnostics
  mixed_balanced.json  same model on the balanced subset SF1-4 (no failed cells)
  contrasts.csv        each configuration vs Spark-local per SF: ratio, 95% CI, Welch t on log run means, Holm-adjusted p
  exponents.csv        per-configuration scaling exponent from mixed model with random run intercept
  feasibility.csv      completion counts, Wilson 95% CI, max sustainable SF, memory headroom, failure mode
  energy_checks.json   correlation with latency, term shares, one-at-a-time coefficient sensitivity
"""
import os as _os
LH = _os.environ.get("LH_ROOT", _os.path.dirname(_os.path.abspath(__file__)))
import json, os, sys, warnings
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm
warnings.filterwarnings("ignore")
sys.path.insert(0, f"{LH}")
from analysis_lib import PMIN, PMAX, WMEM, PUE, VCPU

R = f"{LH}/results"; OUT = f"{R}/rev2"; os.makedirs(OUT, exist_ok=True)
EXP_A = ["duckdb", "polars", "polars-stream", "spark-local-default", "spark-local", "spark-cluster"]
EXP_B = ["polars-tuned", "spark-local-tuned"]
SENS = []
QCLASS = {"q1": "scan", "q6": "scan", "q3": "join", "q5": "join", "q9": "join", "q10": "join", "q13": "highcard", "q18": "highcard"}
rng = np.random.default_rng(20261003)

Q = pd.read_csv(f"{R}/query_obs.csv")
W = Q[Q.phase == "warm"].copy()
ST = pd.read_csv(f"{R}/run_summary.csv")
ok_runs = set(ST[(ST["mode"] == "single") & (ST.status == "ok")].run_id)
W["run_id"] = W.engine + "_sf" + W.sf.astype(str) + "_single" + np.where(W.sf > 8, "1", "3") + "_r" + W.rep.astype(str)
W = W[W.run_id.isin(ok_runs)]

# ---------- 1. reduce to independent units ----------
RQ = (W.groupby(["engine", "sf", "rep", "run_id", "q"]).lat.median().rename("lat").reset_index())
RQ["qclass"] = RQ.q.map(QCLASS); RQ["loglat"] = np.log(RQ.lat); RQ["lsf"] = np.log2(RQ.sf)
RQ.to_csv(f"{OUT}/run_query.csv", index=False)
RL = RQ.groupby(["engine", "sf", "rep", "run_id"]).loglat.mean().rename("loggm").reset_index()
RL["gm"] = np.exp(RL.loggm); RL.to_csv(f"{OUT}/run_level.csv", index=False)

# ---------- 2. cell summaries: t-based CI on run means + two-stage bootstrap ----------
def two_stage_boot(sub, B=2000):
    """Two-stage (hierarchical) bootstrap: resample processes, then warm passes within the chosen processes;
    statistic = geometric mean over queries of the per-query median. Vectorized."""
    runs = sorted(sub.run_id.unique()); qs = sorted(sub.q.unique()); n = len(runs)
    arrs = []
    for q in qs:
        m = [np.sort(sub[(sub.run_id == r) & (sub.q == q)].lat.values) for r in runs]
        k = min(len(x) for x in m); arrs.append(np.array([x[:k] for x in m]))   # (n_runs, k)
    ri = rng.integers(0, n, size=(B, n))
    logs = np.zeros(B)
    for M in arrs:
        k = M.shape[1]
        pi = rng.integers(0, k, size=(B, n, k))
        draws = M[ri[:, :, None], pi].reshape(B, n * k)
        logs += np.log(np.median(draws, axis=1))
    return np.percentile(np.exp(logs / len(arrs)), [2.5, 97.5])

rows = []
for (e, sf), g in RL.groupby(["engine", "sf"]):
    n = len(g); m = g.loggm.mean(); sd = g.loggm.std(ddof=1) if n > 1 else np.nan
    if n > 1:
        h = stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n); lo, hi = np.exp(m - h), np.exp(m + h)
    else:
        lo = hi = np.nan
    blo, bhi = two_stage_boot(W[(W.engine == e) & (W.sf == sf)]) if n > 1 else (np.nan, np.nan)
    rows.append(dict(engine=e, sf=sf, n_runs=n, gm=np.exp(m), t_lo=lo, t_hi=hi, boot_lo=blo, boot_hi=bhi,
                     cv_runs=float(np.std(np.exp(g.loggm), ddof=1) / np.mean(np.exp(g.loggm))) if n > 1 else np.nan,
                     experiment=("A" if e in EXP_A else "B" if e in EXP_B else "S" if e in SENS else "aux")))
CS = pd.DataFrame(rows); CS.to_csv(f"{OUT}/cell_summary.csv", index=False)

# ---------- 3. mixed model on Experiment A ----------
def fit_mixed(df, formula, reml=True):
    df = df.copy(); df["grp"] = 1
    vc = {"run": "0 + C(run_id)", "query": "0 + C(q)"}
    m = sm.MixedLM.from_formula(formula, groups="grp", vc_formula=vc, re_formula="0", data=df)
    return m.fit(reml=reml, method=["lbfgs", "powell"])

def mixed_report(df, tag):
    full = "loglat ~ C(engine, Treatment('spark-local')) * C(qclass) + C(engine, Treatment('spark-local')) * lsf"
    res = fit_mixed(df, full)
    ml_full = fit_mixed(df, full, reml=False)
    lrts = {}
    for name, red in {
        "engine_x_lsf": "loglat ~ C(engine, Treatment('spark-local')) * C(qclass) + lsf",
        "engine_x_qclass": "loglat ~ C(engine, Treatment('spark-local')) + C(qclass) + C(engine, Treatment('spark-local')) * lsf",
        "engine_main": "loglat ~ C(qclass) + lsf"}.items():
        mr = fit_mixed(df, red, reml=False)
        lr = 2 * (ml_full.llf - mr.llf); dfd = len(ml_full.fe_params) - len(mr.fe_params)
        lrts[name] = dict(LR=float(lr), df=int(dfd), p=float(stats.chi2.sf(lr, dfd)))
    resid = df.loglat.values - res.fittedvalues.values
    sw = stats.shapiro(resid if len(resid) <= 5000 else rng.choice(resid, 5000, replace=False))
    lev = stats.levene(*[resid[df.engine.values == e] for e in df.engine.unique()], center="median")
    vcs = dict(zip(["run", "query"], [float(v) for v in res.vcomp])) if hasattr(res, "vcomp") else {}
    rep = dict(tag=tag, n_obs=int(len(df)), n_runs=int(df.run_id.nunique()), n_queries=int(df.q.nunique()),
               configs=sorted(df.engine.unique().tolist()), sfs=sorted(df.sf.unique().tolist()),
               lrt=lrts, residual_var=float(res.scale), var_components=vcs,
               shapiro_W=float(sw.statistic), shapiro_p=float(sw.pvalue),
               levene_W=float(lev.statistic), levene_p=float(lev.pvalue),
               resid_skew=float(stats.skew(resid)), resid_kurt=float(stats.kurtosis(resid)),
               fe={k: [float(v), float(res.bse[k])] for k, v in res.fe_params.items()})
    return rep

A = RQ[RQ.engine.isin(EXP_A) & (RQ.sf <= 8)].copy()
print("cells done", flush=True)
main = mixed_report(A, "Experiment A, SF1-8 (completed runs)")
print("main mixed done", flush=True)
json.dump(main, open(f"{OUT}/mixed_main.json", "w"), indent=1)
bal = mixed_report(A[A.sf <= 4], "Experiment A, SF1-4 (balanced: no failed cells)")
print("balanced done", flush=True)
json.dump(bal, open(f"{OUT}/mixed_balanced.json", "w"), indent=1)

# ---------- 4. pairwise contrasts in pre-specified families, Holm within family ----------
def welch(base_e, e, sf):
    base = RL[(RL.engine == base_e) & (RL.sf == sf)].loggm; x = RL[(RL.engine == e) & (RL.sf == sf)].loggm
    if len(x) < 2 or len(base) < 2: return None
    t = stats.ttest_ind(base, x, equal_var=False); d = base.mean() - x.mean()
    vb, vx = base.var(ddof=1) / len(base), x.var(ddof=1) / len(x); se = np.sqrt(vb + vx)
    dof = se**4 / (vb**2 / (len(base) - 1) + vx**2 / (len(x) - 1)); h = stats.t.ppf(0.975, dof) * se
    return dict(sf=sf, engine=e, base=base_e, ratio=np.exp(d), lo=np.exp(d - h), hi=np.exp(d + h),
                t=t.statistic, df=dof, p=t.pvalue, n_base=len(base), n=len(x))
FAM = {
  "F1 embedded vs Spark-stock": [("spark-local-default", e, sf) for e in ["duckdb", "polars", "polars-stream"] for sf in (1, 2, 4, 8)],
  "F2 Spark configurations": [("spark-local-default", "spark-local", sf) for sf in (1, 2, 4, 8)] + [("spark-local", "spark-cluster", sf) for sf in (1, 2, 4, 8)],
  "F3 Experiment B vs A counterpart": [("polars", "polars-tuned", sf) for sf in (1, 2, 4)] + [("spark-local", "spark-local-tuned", sf) for sf in (1, 8)],
  "F4 COST baseline": [(b, "duckdb-1t", sf) for b in ("spark-local-default", "spark-local") for sf in (1, 2, 4, 8)],
  "F5 extension": [("spark-local", e, 16) for e in ("duckdb", "polars-stream")],
  "F6 embedded vs Spark-local": [("spark-local", e, sf) for e in ["duckdb", "polars", "polars-stream"] for sf in (1, 2, 4, 8)],
}
crow = []
for fam, items in FAM.items():
    rr = [r for r in (welch(*it) for it in items) if r is not None]
    order = sorted(range(len(rr)), key=lambda k: rr[k]["p"]); m = len(rr); running = 0
    for rank, k in enumerate(order):
        running = max(running, min(1.0, (m - rank) * rr[k]["p"])); rr[k]["p_holm"] = running; rr[k]["family"] = fam; rr[k]["m"] = m
    crow += rr
CT = pd.DataFrame(crow); CT.to_csv(f"{OUT}/contrasts.csv", index=False)

# ---------- 5. scaling exponents with random run intercept ----------
ex = []
for e in EXP_A + ["polars-tuned"]:
    d = RQ[(RQ.engine == e) & (RQ.sf <= 8)].copy()
    if d.sf.nunique() < 2: continue
    d["l2"] = np.log(d.sf)
    r = smf.mixedlm("loglat ~ l2 + C(q)", d, groups=d["run_id"]).fit(reml=True)
    b = r.fe_params["l2"]; se = r.bse["l2"]
    ex.append(dict(engine=e, b=b, lo=b - 1.96 * se, hi=b + 1.96 * se, n_runs=d.run_id.nunique()))
pd.DataFrame(ex).to_csv(f"{OUT}/exponents.csv", index=False)

# ---------- 6. feasibility as outcome ----------
def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; den = 1 + z**2 / n; c = (p + z**2 / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / den
    return (max(0, c - h), min(1, c + h))
S = ST[ST["mode"] == "single"]
fe = []
PK = pd.read_csv(f"{R}/peak_rss_all.csv").set_index(["engine", "sf"]).peak_rss_gb
for (e, sf), g in S.groupby(["engine", "sf"]):
    if e in ("polars-sql", "duckdb-1t"): continue
    k = int((g.status == "ok").sum()); n = len(g); lo, hi = wilson(k, n)
    modes = sorted(set(g.status[g.status != "ok"]))
    fq = sorted(set(x for x in g.failed_at.dropna() if isinstance(x, str)))
    fe.append(dict(engine=e, sf=sf, completed=k, runs=n, p_complete=k / n, wilson_lo=lo, wilson_hi=hi,
                   failure_mode=",".join(modes), failed_query=",".join(fq),
                   peak_rss_gb=float(PK.get((e, sf), np.nan)),
                   headroom_gb=(6.0 - float(PK.get((e, sf), np.nan))) if k == n else np.nan,
                   experiment=("A" if e in EXP_A else "B" if e in EXP_B else "S" if e in SENS else "aux")))
F = pd.DataFrame(fe)
mss = {e: max([sf for sf in g.sf if g[g.sf == sf].p_complete.iloc[0] == 1.0] + [0]) for e, g in F.groupby("engine")}
F["max_sustainable_sf"] = F.engine.map(mss)
F.to_csv(f"{OUT}/feasibility.csv", index=False)
CST = pd.read_csv(f"{R}/conc_status.csv")
cf = []
for (e, sf, n), g in CST.groupby(["engine", "sf", "n"]):
    k = int((g.status == "ok").sum()); lo, hi = wilson(k, len(g))
    cf.append(dict(engine=e, sf=sf, streams=n, completed=k, runs=len(g), wilson_lo=lo, wilson_hi=hi))
pd.DataFrame(cf).to_csv(f"{OUT}/feasibility_concurrency.csv", index=False)

# ---------- 7. energy model checks ----------
WW = W.copy(); WW["cpu_c"] = np.minimum(WW.cpu_s, VCPU * WW.lat)
def E(t, c, m, pmin=PMIN, pmax=PMAX, wmem=WMEM, pue=PUE):
    return pue * (VCPU * pmin * t + (pmax - pmin) * c + wmem * np.maximum(m, 0) * t)
WW["e"] = E(WW.lat, WW.cpu_c, WW.mem_gb)
cell = WW.groupby(["engine", "sf", "q"]).agg(lat=("lat", "median"), e=("e", "median")).reset_index()
pr = stats.pearsonr(np.log(cell.lat), np.log(cell.e)); sp = stats.spearmanr(cell.lat, cell.e)
# term shares
WW["static"] = PUE * VCPU * PMIN * WW.lat; WW["dyn"] = PUE * (PMAX - PMIN) * WW.cpu_c; WW["memt"] = PUE * WMEM * np.maximum(WW.mem_gb, 0) * WW.lat
shares = {}
for e in ["duckdb", "polars-stream", "spark-local", "spark-cluster"]:
    d = WW[(WW.engine == e) & (WW.sf <= 8)]; tot = d[["static", "dyn", "memt"]].sum()
    shares[e] = {k: float(v / tot.sum()) for k, v in tot.items()}
# one-at-a-time sensitivity of the Spark-local / DuckDB energy ratio (per warm pass, SF1 and SF8)
def ratio(sf, **kw):
    d = WW[WW.sf == sf].copy(); d["e2"] = E(d.lat, d.cpu_c, d.mem_gb, **kw)
    pm = d.groupby(["engine", "q"]).e2.median().groupby("engine").sum()
    return float(pm["spark-local"] / pm["duckdb"])
sens = {}
for sf in (1, 8):
    base = ratio(sf); sens[f"sf{sf}_base"] = base
    for par, val in [("pmin", PMIN), ("pmax", PMAX), ("wmem", WMEM), ("pue", PUE)]:
        for f in (0.5, 1.5):
            sens[f"sf{sf}_{par}_x{f}"] = ratio(sf, **{par: val * f})
# residual information beyond latency: R^2 of log energy on log latency
lr = stats.linregress(np.log(cell.lat), np.log(cell.e))
json.dump(dict(pearson_log=float(pr.statistic), pearson_p=float(pr.pvalue), spearman=float(sp.statistic),
               r2_log=float(lr.rvalue**2), slope_log=float(lr.slope), n_cells=int(len(cell)),
               term_shares=shares, sensitivity=sens), open(f"{OUT}/energy_checks.json", "w"), indent=1)
print("rev2 analysis written to", OUT)
