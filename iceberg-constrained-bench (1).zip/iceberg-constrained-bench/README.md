# Resource-Constrained Query Processing over Apache Iceberg

Experimental artifact for the article **"Resource-Constrained Query Processing over Apache Iceberg: DuckDB, Polars and Apache Spark"** by Ramakrishna Kolikipogu, Kommu Gangadhara Rao, Vootla Subba Ramaiah, K. Rajitha and S. Aruna.

The artifact contains the benchmark harness, the query texts, all raw per-run measurements (0.2 s traces), query answers, the statistical analysis and the figure scripts. Every number in the article can be regenerated from the files in `results/` without re-running the experiments.

## Study design in brief

| Item | Setting |
|---|---|
| Engines | DuckDB 1.5.5, Polars 1.44.2 (in-memory and streaming), Apache Spark 4.2.0 |
| Table format | Apache Iceberg via PyIceberg 0.12.0 SqlCatalog (SQLite), local ext4 storage |
| Workload | TPC-H Q1, Q3, Q5, Q6, Q9, Q10, Q13, Q18 (qualification parameters) |
| Scale factors | 1, 2, 4, 8 (main design); 16, 32 (memory and spill extension) |
| Node | 2 vCPUs, 8 GB RAM, cgroup memory limit 6,273,757,184 bytes (5.84 GiB) |
| Unit of analysis | one fresh process per repetition (page cache dropped before each) |
| Experiment A | defaults or documented baselines, no query rewriting |
| Experiment B | targeted optimizations (Polars Q9 semi-join rewrite; Spark disk-frugal configuration) |

Spark reads the Parquet data files selected by the same Iceberg snapshot (PyIceberg `plan_files()`), because the `iceberg-spark-runtime` jar could not be obtained in the measurement environment. DuckDB uses `iceberg_scan` and Polars uses `scan_iceberg`.

### Configurations

| Name in paper | Engine key in code | Experiment |
|---|---|---|
| DuckDB | `duckdb` | A |
| Polars in-memory | `polars` | A |
| Polars streaming | `polars-stream` | A |
| Spark-stock | `spark-local-default` | A |
| Spark-local | `spark-local` | A |
| Spark co-located | `spark-cluster` | A |
| Polars-mem+fix | `polars-tuned` | B |
| Spark disk-frugal | `spark-local-tuned` | B |
| DuckDB-1t (COST baseline) | `duckdb-1t` | auxiliary |

## Repository layout

```
engines.py            engine adapters (DuckDB, Polars, Spark local / stock / frugal / co-located)
queries.py            SQL texts of the eight TPC-H queries
polars_native.py      Polars LazyFrame plans (NATIVE) and the Q9 semi-join rewrite (TUNED)
runner.py, worker.py  process-per-run harness with 0.2 s memory/CPU sampling
cluster.sh            single-host Spark standalone master + 2 workers
load_iceberg.py       load SF1-8 Parquet into Iceberg
load_large.py         generate and load SF16/SF32 part by part
analyze.py            per-cell tables, energy and cost model, base figures
discussion_calcs.py   COST, fixed-cost decomposition, cross-join threshold (needs the Iceberg data)
stats_rev2.py         mixed-effects models, Holm-adjusted contrasts, two-stage bootstrap,
                      feasibility (Wilson intervals), energy-model checks
correctness_ref.py    TPC-H reference answers and exact decimal recomputation (needs the Iceberg data)
figs_rev2.py          scaling and feasibility figures
diag.py, spillcheck.py, pruning.py, access_ab.py   diagnostics and control experiments
env_manifest.py       writes ENVIRONMENT.md
scripts/              the run scripts in the order they were executed
results/              all raw and derived results (see below)
figures/              figures regenerated from results/
reproduce.sh          end-to-end reproduction
```

## Results directory

| Path | Content |
|---|---|
| `results/runs/*.json` | one file per process: events, per-query latencies, 0.2 s memory/CPU samples, status |
| `results/answers/*.pkl` | query answers per engine, scale factor and repetition |
| `results/status.csv` | completed/attempted processes per configuration and scale factor |
| `results/rev2/run_query.csv` | process x query observations (median of three warm executions) |
| `results/rev2/cell_summary.csv` | process-level geometric means, t intervals and two-stage bootstrap intervals |
| `results/rev2/mixed_main.json`, `mixed_balanced.json` | mixed-effects models and likelihood-ratio tests |
| `results/rev2/contrasts.csv` | pre-specified contrast families F1-F6 with Holm-adjusted p-values |
| `results/rev2/exponents.csv` | scaling exponents per configuration |
| `results/rev2/feasibility*.csv` | completion, Wilson intervals, maximum sustainable SF, headroom, failure mode |
| `results/rev2/energy_checks.json` | correlation with latency, term shares, coefficient sensitivity |
| `results/rev2/correctness_reference.json` | TPC-H answer check and exact decimal reference values |
| `results/diag/` | Polars Q9 plans (comma-join and explicit-join) and diagnostic runs |
| `results/runs_failed_disk/` | Spark SF32 runs that exhausted scratch disk |
| `results/runs_recheck/` | DuckDB parity re-runs |

## Quick start: regenerate the statistics and figures

No Iceberg data is needed for this step.

```bash
pip install -r requirements.txt
python3 analyze.py
python3 stats_rev2.py
python3 figs_rev2.py
```

Outputs are written to `results/`, `results/rev2/` and `figures/`.

## Full reproduction

Requirements: Linux, root access (the harness drops the page cache), Python 3.13, OpenJDK 21, an Apache Spark 4.2.0 distribution, and about 60 GB of free disk.

```bash
pip install -r requirements.txt
export SPARK_HOME=/path/to/spark-4.2.0          # Spark jars and bin/spark-class
export PYSPARK_SRC=/path/to/pyspark-4.2.0       # pyspark source tree (python/ package)
./reproduce.sh
```

`reproduce.sh` generates the data with `tpchgen-cli`, loads it into Iceberg, executes every run script in order and re-runs the analysis. Measured execution totals about 10 hours on a 2-vCPU node, plus data generation and loading (about 3 to 5 hours including SF16 and SF32). Measurements are sensitive to background load: do not run other CPU-intensive work during the experiments.

Paths default to the repository root; set `LH_ROOT` to use another location.

## Execution environment

See `ENVIRONMENT.md` for the OS and kernel, CPU model, cgroup limit, filesystem, JVM flags, every Spark configuration, package versions and build revisions, data-generation commands, query texts and random seeds.

## Citation

See `CITATION.cff`. Please cite the article when using this artifact.

## License

MIT (see `LICENSE`).
